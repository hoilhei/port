(function(){
  // Intro loader: text hold -> vertical line covers screen -> whole overlay fades to reveal hero
  var introLoader = document.getElementById('introLoader');
  var introDone = false;
  function finishIntro(){
    if(introDone) return;
    introDone = true;
    document.body.classList.remove('intro-lock');
    introLoader.classList.add('is-done');
  }
  introLoader.addEventListener('animationend', function(e){
    if(e.target === introLoader) finishIntro();
  });
  setTimeout(finishIntro, 2100); // safety fallback in case animationend doesn't fire

  // Nav scroll state
  var nav = document.getElementById('nav');
  var topBtn = document.getElementById('topBtn');
  window.addEventListener('scroll', function(){
    var y = window.scrollY;
    nav.classList.toggle('is-scrolled', y > 40);
    topBtn.classList.toggle('is-visible', y > 500);
  });

  // Mobile menu
  var burger = document.getElementById('burgerBtn');
  var mobileMenu = document.getElementById('mobileMenu');
  var mobileMenuClose = document.getElementById('mobileMenuClose');
  burger.addEventListener('click', function(){
    var open = mobileMenu.classList.toggle('is-open');
    burger.setAttribute('aria-expanded', open);
  });
  mobileMenuClose.addEventListener('click', function(){
    mobileMenu.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
  });
  mobileMenu.querySelectorAll('a').forEach(function(a){
    a.addEventListener('click', function(){ mobileMenu.classList.remove('is-open'); });
  });

  // Tabs
  var tabBtns = document.querySelectorAll('.tab-btn');
  var panels = document.querySelectorAll('.tab-panel');
  tabBtns.forEach(function(btn){
    btn.addEventListener('click', function(){
      tabBtns.forEach(function(b){ b.classList.remove('is-active'); b.setAttribute('aria-selected','false'); });
      panels.forEach(function(p){ p.classList.remove('is-active'); });
      btn.classList.add('is-active');
      btn.setAttribute('aria-selected','true');
      document.querySelector('.tab-panel[data-panel="'+btn.dataset.tab+'"]').classList.add('is-active');
    });
  });

  // Work carousel — center-focused slide with peeking neighbors, infinite seamless loop
  (function(){
   try{
    var root = document.getElementById('workCarousel');
    if(!root) return;
    var viewport = root.querySelector('.carousel-viewport');
    var track = document.getElementById('carouselTrack');
    var realSlides = Array.prototype.slice.call(track.querySelectorAll('.slide'));
    var realCount = realSlides.length;
    var dotsWrap = document.getElementById('carDots');
    var prevBtn = document.getElementById('carPrev');
    var nextBtn = document.getElementById('carNext');
    var playBtn = document.getElementById('carPlay');
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var isPlaying = true;
    var autoplayTimer = null;

    // clone 2 slides at each end so that even while parked on a clone-boundary slide,
    // both its left and right neighbors are always real-looking content (never an empty gap) —
    // the outermost clones are only ever used as peek-neighbors, never actually landed on
    var prependClones = [realSlides[realCount - 2].cloneNode(true), realSlides[realCount - 1].cloneNode(true)];
    var appendClones = [realSlides[0].cloneNode(true), realSlides[1].cloneNode(true)];
    prependClones.concat(appendClones).forEach(function(c){ c.setAttribute('aria-hidden', 'true'); });
    prependClones.forEach(function(c){ track.insertBefore(c, realSlides[0]); });
    appendClones.forEach(function(c){ track.appendChild(c); });

    var slides = Array.prototype.slice.call(track.children); // [c(N-2), c(N-1), real0..realN-1, c(0), c(1)]
    var realStart = 2, realEnd = realStart + realCount - 1;
    var activeIndex = realStart; // real0, the card labeled "01"

    var PAUSE_ICON = '<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><rect x="3" y="2" width="4" height="12"/><rect x="9" y="2" width="4" height="12"/></svg>';
    var PLAY_ICON = '<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M4 2l10 6-10 6V2z"/></svg>';

    realSlides.forEach(function(_, i){
      var dot = document.createElement('button');
      dot.className = 'car-dot';
      dot.setAttribute('aria-label', (i + 1) + '번째 프로젝트로 이동');
      dot.addEventListener('click', function(){ goTo(realStart + i); restartAutoplay(); });
      dotsWrap.appendChild(dot);
    });
    var dots = Array.prototype.slice.call(dotsWrap.children);

    var currentX = 0;
    function getFocusX(vw){
      // The focus point belongs to the carousel viewport, not the browser
      // window. CSS controls the responsive percentage for each breakpoint.
      var focusPercent = parseFloat(getComputedStyle(viewport).getPropertyValue('--carousel-focus-x'));
      if(!Number.isFinite(focusPercent)) focusPercent = 50;
      return vw * Math.max(0, Math.min(100, focusPercent)) / 100;
    }
    function render(instant, extraFreezeEls){
      var active = slides[activeIndex];
      if(!active) return; // defensive guard — never crash on an out-of-range index
      var vw = viewport.clientWidth;
      var center = active.offsetLeft + active.offsetWidth / 2;
      currentX = getFocusX(vw) - center;
      var frozen = [];
      if(instant){
        // Freeze the media position while the track is resized or corrected
        // from a cloned boundary. Otherwise the track jump and the media's
        // own top/transform transition can briefly show the same image twice.
        var mediaEls = slides.map(function(slide){ return slide.querySelector('.slide-media'); }).filter(Boolean);
        frozen = [track].concat(mediaEls, extraFreezeEls || []);
        frozen.forEach(function(el){ el.style.transition = 'none'; });
      }
      track.style.transform = 'translateX(' + currentX + 'px)';
      slides.forEach(function(s, i){ s.classList.toggle('is-active', i === activeIndex); });
      var realIdx = ((activeIndex - realStart) % realCount + realCount) % realCount;
      dots.forEach(function(d, i){ d.classList.toggle('is-active', i === realIdx); });
      if(instant){
        void track.offsetWidth; // force a reflow while the swapped elements' transitions are suppressed
        frozen.forEach(function(el){ el.style.transition = ''; });
      }
    }
    function goTo(i){
      // clamp so activeIndex can never land outside the extended clone-padded array
      activeIndex = Math.max(0, Math.min(slides.length - 1, i));
      render();
      // only arm the fallback correction when we've actually landed on the clone-boundary slide —
      // scheduling it on every navigation left stale timers that could fire at the wrong moment
      if(activeIndex === realStart - 1 || activeIndex === realEnd + 1){
        scheduleCloneCheck();
      }
    }
    function next(){ goTo(activeIndex + 1); }
    function prev(){ goTo(activeIndex - 1); }

    // when the track finishes sliding onto the clone-boundary slide, silently re-point to the
    // equivalent real slide — its neighbors (still within the padded array) look identical either way.
    // Only the outgoing (clone) and incoming (real) slide's own panels are frozen for the swap —
    // every other slide's panel keeps animating normally, even if it's still mid-transition.
    function correctClonePosition(){
      var nextIndex = null;
      if(activeIndex === realStart - 1) nextIndex = realEnd;
      else if(activeIndex === realEnd + 1) nextIndex = realStart;
      if(nextIndex === null) return;
      activeIndex = nextIndex;
      // The incoming real card contains the same content as the clone that
      // was just visible. Freeze only its panel during the silent correction
      // so the text does not rise a second time from below.
      var incomingPanel = slides[activeIndex].querySelector('.slide-panel');
      render(true, incomingPanel ? [incomingPanel] : []);
    }
    // single deterministic timer as the ONLY correction trigger — previously this also listened
    // for 'transitionend', but that could fire independently of (and race with) this timer and
    // cause a mistimed double-correction. One source of truth removes that entirely.
    var cloneCheckTimer = null;
    function getCloneCorrectionDelay(){
      var rawDuration = getComputedStyle(track).getPropertyValue('--carousel-transition-duration').trim();
      var duration = parseFloat(rawDuration);
      if(!Number.isFinite(duration)) return 930;
      var durationMs = /ms$/i.test(rawDuration) ? duration : duration * 1000;
      return durationMs + 80;
    }
    function scheduleCloneCheck(){
      if(cloneCheckTimer) clearTimeout(cloneCheckTimer);
      cloneCheckTimer = setTimeout(correctClonePosition, getCloneCorrectionDelay());
    }

    function startAutoplay(){
      if(reduceMotion) return;
      stopAutoplay();
      autoplayTimer = setInterval(next, 4500);
    }
    function stopAutoplay(){ if(autoplayTimer){ clearInterval(autoplayTimer); autoplayTimer = null; } }
    function restartAutoplay(){ if(isPlaying) startAutoplay(); }

    prevBtn.addEventListener('click', function(){ prev(); restartAutoplay(); });
    nextBtn.addEventListener('click', function(){ next(); restartAutoplay(); });
    // The play/pause control is optional. Autoplay must still work when the
    // control is not rendered in the carousel markup.
    if(playBtn){
      playBtn.addEventListener('click', function(){
        isPlaying = !isPlaying;
        playBtn.innerHTML = isPlaying ? PAUSE_ICON : PLAY_ICON;
        playBtn.setAttribute('aria-label', isPlaying ? '일시정지' : '재생');
        if(isPlaying) startAutoplay(); else stopAutoplay();
      });
    }
    root.addEventListener('mouseenter', stopAutoplay);
    root.addEventListener('mouseleave', function(){ if(!isDragging) restartAutoplay(); });
    window.addEventListener('resize', function(){ render(true); });

    // Drag / swipe support
    var isDragging = false, dragStartX = 0, dragDelta = 0;
    track.style.cursor = 'grab';
    function dragStart(x){
      isDragging = true; dragStartX = x; dragDelta = 0;
      track.style.transition = 'none';
      track.style.cursor = 'grabbing';
      stopAutoplay();
    }
    function dragMove(x){
      if(!isDragging) return;
      dragDelta = x - dragStartX;
      track.style.transform = 'translateX(' + (currentX + dragDelta) + 'px)';
    }
    function dragEnd(){
      if(!isDragging) return;
      isDragging = false;
      track.style.transition = '';
      track.style.cursor = 'grab';
      var threshold = 60;
      if(dragDelta <= -threshold){ next(); }
      else if(dragDelta >= threshold){ prev(); }
      else { render(); }
      restartAutoplay();
    }
    track.addEventListener('pointerdown', function(e){
      if(e.button !== 0) return;
      // Keep the web popup arrow from being captured as a carousel drag.
      if(e.target.closest('.lightbox-trigger')) return;
      dragStart(e.clientX);
      track.setPointerCapture && track.setPointerCapture(e.pointerId);
    });
    track.addEventListener('pointermove', function(e){ dragMove(e.clientX); });
    track.addEventListener('pointerup', dragEnd);
    track.addEventListener('pointercancel', dragEnd);
    track.addEventListener('dragstart', function(e){ e.preventDefault(); }); // stop native image/link drag ghosting

    render(true);
    if(reduceMotion){
      if(playBtn) playBtn.style.display = 'none';
    } else {
      startAutoplay();
    }
   } catch(e){ console.error('Work carousel init failed:', e); }
  })();

  // Services — pin the section and run six cards as an endless vertical slider.
  (function(){
    try{
      var stage = document.querySelector('#project .cards');
      if(!stage) return;
      var projectSection = document.getElementById('project');
      var processSection = document.getElementById('process');

      function goToProcessSection(){
        if(!processSection) return;
        var navHeight = nav ? nav.getBoundingClientRect().height : 0;
        var processTop = processSection.getBoundingClientRect().top + window.scrollY;
        window.scrollTo({top:Math.max(0, processTop - navHeight), behavior:'smooth'});
      }

      // On compact layouts the card list is static, but the same two-drag
      // gesture should still move to the next section.
      if(window.matchMedia && window.matchMedia('(max-width:968px)').matches){
        var compactDragging = false;
        var compactMoved = false;
        var compactStartY = 0;
        var compactDragCount = 0;
        stage.style.touchAction = 'none';
        stage.addEventListener('pointerdown', function(e){
          if(e.button !== 0) return;
          if(e.target.closest('.work-link')) return;
          compactDragging = true;
          compactMoved = false;
          compactStartY = e.clientY;
          stage.setPointerCapture && stage.setPointerCapture(e.pointerId);
        });
        stage.addEventListener('pointermove', function(e){
          if(!compactDragging) return;
          if(Math.abs(e.clientY - compactStartY) > 6) compactMoved = true;
        });
        function endCompactDrag(e){
          if(!compactDragging) return;
          compactDragging = false;
          if(compactMoved){
            compactDragCount += 1;
            if(compactDragCount >= 2) goToProcessSection();
          }
          if(stage.releasePointerCapture && e && stage.hasPointerCapture && stage.hasPointerCapture(e.pointerId)){
            stage.releasePointerCapture(e.pointerId);
          }
        }
        stage.addEventListener('pointerup', endCompactDrag);
        stage.addEventListener('pointercancel', endCompactDrag);
        return;
      }

      var baseCards = Array.prototype.slice.call(stage.querySelectorAll('.card'));
      if(baseCards.length < 2) return;

      // Project cards are authored in index.html; do not clone card content.
      var cards = baseCards.slice();

      var items = cards.map(function(card, i){
        return {card:card, column:i % 2, row:Math.floor(i / 2)};
      });

      function place(item){
        item.card.style.top = '40px';
        item.card.style.left = item.column === 0 ? '24px' : 'auto';
        item.card.style.right = item.column === 1 ? '24px' : 'auto';
        item.card.classList.remove('is-settled');
      }
      items.forEach(place);

      if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches){
        projectSection.classList.add('is-static');
        items.forEach(function(item){
          item.card.style.opacity = '1';
          item.card.style.transform = 'translateY(' + (item.row * item.card.offsetHeight) + 'px)';
        });
        return;
      }

      var speed = 38;
      var elapsed = 0;
      var previousTime = null;
      var isPaused = false;
      var isDragging = false;
      var dragStartY = 0;
      var dragStartOffset = 0;
      var dragOffset = 0;
      var dragMoved = false;
      var dragCount = 0;
      var suppressCardClickUntil = 0;
      var sectionChangeStarted = false;
      var DRAGS_TO_NEXT_SECTION = 2;

      stage.style.cursor = 'grab';
      stage.style.touchAction = 'none';
      stage.addEventListener('mouseenter', function(){ isPaused = true; });
      stage.addEventListener('mouseleave', function(){ if(!isDragging) isPaused = false; });
      stage.addEventListener('pointerdown', function(e){
        if(e.button !== 0) return;
        // Let the project arrow receive its own click event; never capture it as a drag.
        if(e.target.closest('.work-link')) return;
        isDragging = true;
        isPaused = true;
        dragMoved = false;
        stage.classList.remove('is-dragging');
        dragStartY = e.clientY;
        dragStartOffset = dragOffset;
        stage.style.cursor = 'grabbing';
        stage.setPointerCapture && stage.setPointerCapture(e.pointerId);
      });
      stage.addEventListener('pointermove', function(e){
        if(!isDragging) return;
        if(Math.abs(e.clientY - dragStartY) > 6){
          dragMoved = true;
          stage.classList.add('is-dragging');
        }
        dragOffset = dragStartOffset + dragStartY - e.clientY;
        renderServiceCards();
      });
      function endServiceDrag(e){
        if(!isDragging) return;
        isDragging = false;
        stage.style.cursor = 'grab';
        if(dragMoved){
          dragCount += 1;
          suppressCardClickUntil = Date.now() + 250;
          window.projectCardClickLockUntil = suppressCardClickUntil;
          if(dragCount >= DRAGS_TO_NEXT_SECTION && !sectionChangeStarted && processSection){
            sectionChangeStarted = true;
            isPaused = true;
            window.setTimeout(function(){
              goToProcessSection();
            }, 180);
          }
        }
        setTimeout(function(){ stage.classList.remove('is-dragging'); }, 0);
        if(stage.releasePointerCapture && e && stage.hasPointerCapture && stage.hasPointerCapture(e.pointerId)){
          stage.releasePointerCapture(e.pointerId);
        }
      }
      stage.addEventListener('pointerup', endServiceDrag);
      stage.addEventListener('pointercancel', endServiceDrag);

      function renderServiceCards(){
        var rect = projectSection.getBoundingClientRect();
        var isVisible = rect.bottom > 0 && rect.top < window.innerHeight;
        // Reveal the project cards when the section top reaches the first-third
        // line of the viewport, instead of waiting for a fixed scroll distance.
        var revealLine = window.innerHeight / 3;
        var cardsReady = rect.top <= revealLine && rect.bottom > 0;
        var cardsEnding = cardsReady && rect.bottom <= revealLine;
        stage.classList.toggle('is-ready', cardsReady);
        stage.classList.toggle('is-ending', cardsEnding);
        if(!isVisible || !cardsReady) return false;

        var stageHeight = stage.clientHeight;
        var cardHeight = items[0].card.offsetHeight;
        // CSS controls the extra space between project card rows.
        var cardGap = parseFloat(getComputedStyle(stage).getPropertyValue('--project-card-gap')) || 60;
        var step = cardHeight + cardGap;
        var rowsPerColumn = Math.ceil(items.length / 2);
        var cycleHeight = step * rowsPerColumn;
        var initialOffset = Math.max(0, cycleHeight - stageHeight);

        items.forEach(function(item){
          var columnPhase = item.column * step * .5;
          var y = item.row * step - (((elapsed * speed + dragOffset) + initialOffset + columnPhase) % cycleHeight);
          while(y < -cardHeight) y += cycleHeight;
          item.card.style.transform = 'translateY(' + y + 'px)';
          item.card.style.opacity = '1';
        });

        return isVisible;
      }

      function animateServiceCards(now){
        if(previousTime === null) previousTime = now;
        var delta = Math.min(50, now - previousTime) / 1000;
        previousTime = now;
        if(!document.hidden && renderServiceCards() && !isPaused && !isDragging) elapsed += delta;
        window.requestAnimationFrame(animateServiceCards);
      }

      renderServiceCards();
      window.requestAnimationFrame(animateServiceCards);
    } catch(e){ console.error('Services slider init failed:', e); }
  })();

  // Focus section — folder windows rise from the bottom as the page scrolls, each stopping short of the top
  (function(){
   try{
    var pinWrap = document.getElementById('folderPinWrap');
    if(!pinWrap) return;
    var sticky = pinWrap.querySelector('.folder-sticky');
    var windows = Array.prototype.slice.call(pinWrap.querySelectorAll('.folder-window'));
    var folderSection = pinWrap.closest('.folder-section');
    var navEl = document.getElementById('nav');
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if(reduceMotion){
      pinWrap.classList.add('is-static');
      return;
    }

    function clamp(v, min, max){ return Math.max(min, Math.min(max, v)); }
    // CSS owns the folder positions. Read the resolved values here so the
    // scroll animation automatically follows desktop/tablet/mobile overrides.
    function getRestingPositions(){
      return windows.map(function(win){
        var value = parseFloat(getComputedStyle(win).getPropertyValue('--folder-rest-y'));
        return Number.isFinite(value) ? value : -18;
      });
    }

    // Clicking a file brings it to the front — but instead of an ever-incrementing z-index
    // (which could drift out of sync with the natural scroll-driven stacking order), we track
    // only WHICH file is front-most and recompute every window's z-index from scratch on every
    // scroll tick: natural order (i+1) for everyone, except the front-clicked one gets boosted
    // above them all. This can never accumulate into a broken state.
    var frontIndex = null;
    windows.forEach(function(win, i){
      win.addEventListener('click', function(e){
        if(e.target.closest('.folder-tab-arrow')) return;
        frontIndex = (frontIndex === i) ? null : i; // click again to release it back to natural order
        applyStacking();
      });
    });
    function applyStacking(){
      windows.forEach(function(win, i){
        win.style.zIndex = (frontIndex === i) ? (windows.length + 10) : (i + 1);
      });
    }
    applyStacking();

    function update(){
      var rect = pinWrap.getBoundingClientRect();
      var stickyH = sticky.offsetHeight;
      var total = rect.height - stickyH;
      if(total <= 0) return;
      // Start pinning when the folder section reaches the bottom edge of the
      // compact, scrolled navigation bar, keeping the section header in view.
      var pinOffset = navEl ? navEl.getBoundingClientRect().height : 0;
      var scrolled = pinOffset - rect.top;

      // manually pin the sticky box via position:fixed while we're inside the scroll runway —
      // this sidesteps every position:sticky + overflow/ancestor edge case
      if(scrolled <= 0){
        sticky.classList.remove('is-pinned','is-past');
      } else if(scrolled >= total){
        sticky.classList.remove('is-pinned');
        sticky.classList.add('is-past');
      } else {
        sticky.classList.add('is-pinned');
        sticky.classList.remove('is-past');
      }

      var progress = clamp(scrolled / total, 0, 1); // 0 -> 1 across the whole pinned scroll distance
      var animatedCount = Math.max(1, windows.length - 1);
      var slice = 1 / animatedCount;
      var restingPositions = getRestingPositions();

      // Pull the next section upward by the final folder's visible lift so the
      // final gap remains consistent with the configured resting position.
      if(folderSection && windows.length){
        var finalFolder = windows[windows.length - 1];
        var liftOffset = finalFolder.offsetHeight * Math.abs(restingPositions[windows.length - 1]) / 100;
        folderSection.style.setProperty('--folder-lift-offset', -liftOffset + 'px');
      }

      windows.forEach(function(win, i){
        // Keep the first folder visible from the moment the Focus section enters.
        // Only the remaining folders rise and stack as the pinned section scrolls.
        if(i === 0){
          win.style.setProperty('--folder-current-y', restingPositions[i] + '%');
          return;
        }
        var phase = clamp((progress - (i - 1) * slice) / slice, 0, 1);
        var currentY = 100 - phase * (100 - restingPositions[i]);
        win.style.setProperty('--folder-current-y', currentY + '%');
      });
      applyStacking();
    }

    window.addEventListener('scroll', update, {passive:true});
    window.addEventListener('resize', update);
    update();
   } catch(e){ console.error('Focus section init failed:', e); }
  })();

  // Reveal on scroll
  var revealEls = document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, {threshold:.15});
    revealEls.forEach(function(el){ io.observe(el); });
  } else {
    revealEls.forEach(function(el){ el.classList.add('is-visible'); });
  }

  // Back to top
  topBtn.addEventListener('click', function(){
    window.scrollTo({top:0, behavior:'smooth'});
  });

  // Work lightbox — clicking a card's arrow opens a popup with that project's image
  // Process media can be switched from image to video by changing only
  // data-media-type="video" and data-media-src on the .step-media element.
  document.querySelectorAll('.step-media').forEach(function(media){
    var src = media.getAttribute('data-media-src') || '';
    var type = (media.getAttribute('data-media-type') || 'image').toLowerCase();
    if(!src || type !== 'video') return;
    var video = document.createElement('video');
    video.src = src;
    video.controls = true;
    video.playsInline = true;
    video.preload = 'metadata';
    media.replaceChildren(video);
  });

  var lightbox = document.getElementById('lightboxOverlay');
  var lightboxScroll = lightbox.querySelector('.lightbox-scroll');
  var lightboxClose = document.getElementById('lightboxClose');
  var lightboxImg = document.getElementById('lightboxImg');
  var lightboxVideo = document.getElementById('lightboxVideo');
  var lightboxTitle = document.getElementById('lightboxTitle');
  var lightboxDesc = document.getElementById('lightboxDesc');
  var lightboxPeriod = document.getElementById('lightboxPeriod');
  var lightboxTools = document.getElementById('lightboxTools');
  function getToolMark(tool){
    var name = tool.toLowerCase();
    if(name.indexOf('figma') !== -1) return 'Fi';
    if(name.indexOf('photoshop') !== -1) return 'Ps';
    if(name.indexOf('illustrator') !== -1) return 'Ai';
    if(name.indexOf('after effects') !== -1) return 'Ae';
    if(name.indexOf('html') !== -1) return '</>';
    if(name.indexOf('css') !== -1) return '#';
    return tool.slice(0, 2).toUpperCase();
  }
  function renderLightboxTools(value){
    if(!lightboxTools) return;
    lightboxTools.replaceChildren();
    (value || '').split(',').map(function(tool){ return tool.trim(); }).filter(Boolean).forEach(function(tool){
      var item = document.createElement('span');
      item.className = 'lightbox-tool';
      item.title = tool;
      var icon = document.createElement('span');
      icon.className = 'lightbox-tool-icon';
      icon.textContent = getToolMark(tool);
      var label = document.createElement('span');
      label.className = 'lightbox-tool-name';
      label.textContent = tool;
      item.append(icon, label);
      lightboxTools.appendChild(item);
    });
  }
  function updateWebLightboxLinks(btn){
    lightbox.querySelectorAll('.web-lightbox-action').forEach(function(link){
      var action = link.getAttribute('data-lightbox-action');
      var path = action ? btn.getAttribute('data-popup-' + action) : '';
      link.href = path || '#';
      link.hidden = !path;
    });
  }
  function openLightbox(btn){
    // Always show a newly opened popup from the top.
    lightboxScroll.scrollTop = 0;
    var videoSrc = btn.getAttribute('data-popup-video') || '';
    var mediaSrc = btn.getAttribute('data-popup-image') || btn.getAttribute('data-lightbox-src') || '';
    var isVideo = !!videoSrc || /\.(mp4|webm|ogg)(\?.*)?$/i.test(videoSrc || mediaSrc);
    var isProjectPopup = btn.getAttribute('data-lightbox-kind') === 'project';
    var isWebPopup = btn.getAttribute('data-lightbox-kind') === 'web' || !!btn.closest('#web');
    lightbox.querySelector('.lightbox').classList.toggle('is-project-only', isProjectPopup);
    lightbox.querySelector('.lightbox').classList.toggle('is-web-popup', isWebPopup);
    lightboxImg.style.display = isVideo ? 'none' : 'block';
    lightboxVideo.hidden = !isVideo;
    lightboxVideo.pause();
    lightboxVideo.removeAttribute('src');
    lightboxVideo.load();
    if(isVideo){
      lightboxVideo.src = videoSrc || mediaSrc;
      lightboxVideo.load();
    } else {
      lightboxImg.src = mediaSrc;
    }
    lightboxImg.alt = btn.getAttribute('data-lightbox-title') || '';
    lightboxTitle.textContent = btn.getAttribute('data-lightbox-title') || '';
    lightboxDesc.textContent = btn.getAttribute('data-lightbox-desc') || '';
    if(lightboxPeriod) lightboxPeriod.textContent = btn.getAttribute('data-popup-period') || '—';
    renderLightboxTools(btn.getAttribute('data-popup-tools') || '');
    updateWebLightboxLinks(btn);
    lightbox.classList.add('is-open');
  }
  function closeLightbox(){
    lightbox.classList.remove('is-open');
    lightboxVideo.pause();
    lightboxScroll.scrollTop = 0;
  }
  // Each project card opens its own image and text in the lightbox.
  // The arrow owns its popup data directly, so SVG clicks and hover state cannot break it.
  var projectCards = document.querySelector('#project .cards');
  if(projectCards){
    function openProjectCard(card, button){
      var image = card.querySelector('.card-photo img');
      var title = card.querySelector('h3');
      var desc = card.querySelector('.card-body p');
      if(!image) return;
      button.setAttribute('data-lightbox-src', button.getAttribute('data-popup-image') || image.getAttribute('src'));
      button.setAttribute('data-lightbox-title', button.getAttribute('data-popup-title') || (title ? title.textContent.trim() : image.alt));
      button.setAttribute('data-lightbox-desc', desc ? desc.textContent.trim() : '');
      button.setAttribute('data-lightbox-kind', 'project');
      openLightbox(button);
    }

    projectCards.querySelectorAll('.work-link').forEach(function(button){
      button.addEventListener('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        var card = button.closest('.card');
        if(card) openProjectCard(card, button);
      });
    });

    projectCards.addEventListener('click', function(e){
      var card = e.target.closest('#project .card');
      if(!card || e.target.closest('.work-link') || projectCards.classList.contains('is-dragging') || Date.now() < (window.projectCardClickLockUntil || 0)) return;
      var trigger = card.querySelector('.work-link');
      if(!trigger) return;
      e.preventDefault();
      openProjectCard(card, trigger);
    });
  }
  document.querySelectorAll('.lightbox-trigger, [data-lightbox-src]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.preventDefault();
      openLightbox(btn);
    });
  });
  lightboxClose.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', function(e){ if(e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeLightbox(); });

  // Toast helper
  var toast = document.getElementById('toast');
  function showToast(msg){
    toast.textContent = msg;
    toast.classList.add('is-visible');
    setTimeout(function(){ toast.classList.remove('is-visible'); }, 3200);
  }

  // Journal — drag to scroll horizontally with the mouse (touch already scrolls natively)
  (function(){
    try{
      var scroller = document.querySelector('.journal-scroll');
      if(!scroller) return;
      var slider = document.getElementById('journalSlider');
      var currentLabel = document.getElementById('journalSliderCurrent');
      var totalLabel = document.getElementById('journalSliderTotal');
      var cards = Array.prototype.slice.call(scroller.querySelectorAll('.journal-card'));
      var isDown = false, startX = 0, startScroll = 0, moved = false;

      cards.forEach(function(card){
        var image = card.querySelector('.journal-photo img');
        if(!image) return;
        var title = card.querySelector('.journal-body h4');
        var desc = card.querySelector('.journal-body p');
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'button');
        card.setAttribute('aria-label', (title ? title.textContent.trim() : image.alt) + ' 크게 보기');

        function openJournalCard(){
          card.setAttribute('data-lightbox-src', image.currentSrc || image.src);
          card.setAttribute('data-lightbox-title', title ? title.textContent.trim() : image.alt);
          card.setAttribute('data-lightbox-desc', desc ? desc.textContent.trim() : '');
          openLightbox(card);
        }

        card.addEventListener('click', function(){
          if(moved) return;
          openJournalCard();
        });
        card.addEventListener('keydown', function(e){
          if(e.key !== 'Enter' && e.key !== ' ') return;
          e.preventDefault();
          openJournalCard();
        });
      });

      function updateJournalSlider(){
        if(!slider) return;
        var maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth);
        var progress = maxScroll ? (scroller.scrollLeft / maxScroll) * 100 : 0;
        slider.value = progress;

        if(currentLabel && cards.length){
          var closestIndex = 0;
          var closestDistance = Infinity;
          cards.forEach(function(card, index){
            var distance = Math.abs(card.offsetLeft - scroller.scrollLeft);
            if(distance < closestDistance){
              closestDistance = distance;
              closestIndex = index;
            }
          });
          currentLabel.textContent = String(closestIndex + 1).padStart(2, '0');
        }
      }

      if(totalLabel && cards.length) totalLabel.textContent = String(cards.length).padStart(2, '0');
      if(slider){
        slider.addEventListener('input', function(){
          var maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth);
          scroller.scrollLeft = maxScroll * (Number(slider.value) / 100);
        });
      }
      scroller.addEventListener('scroll', updateJournalSlider, {passive:true});
      window.addEventListener('resize', updateJournalSlider);
      updateJournalSlider();
      scroller.addEventListener('pointerdown', function(e){
        if(e.pointerType === 'touch') return; // let touch use native scrolling
        isDown = true; moved = false;
        startX = e.clientX;
        startScroll = scroller.scrollLeft;
        scroller.classList.add('is-dragging');
        scroller.setPointerCapture && scroller.setPointerCapture(e.pointerId);
      });
      scroller.addEventListener('pointermove', function(e){
        if(!isDown) return;
        var delta = e.clientX - startX;
        // A small pointer wobble during a normal click must not cancel the card popup.
        if(Math.abs(delta) > 10) moved = true;
        scroller.scrollLeft = startScroll - delta;
      });
      function endDrag(){
        isDown = false;
        scroller.classList.remove('is-dragging');
      }
      scroller.addEventListener('pointerup', endDrag);
      scroller.addEventListener('pointercancel', endDrag);
      scroller.addEventListener('pointerleave', endDrag);
      // prevent the drag from being interpreted as a click on a card link
      scroller.addEventListener('click', function(e){
        if(!moved) return;
        e.preventDefault();
        e.stopPropagation();
        moved = false;
      }, true);
    } catch(e){ console.error('Journal drag init failed:', e); }
  })();

  // Forms (static demo — no backend)
  var contactForm = document.getElementById('contactForm');
  if(contactForm) contactForm.addEventListener('submit', function(e){
    e.preventDefault();
    this.reset();
    showToast('문의가 접수되었습니다. 곧 연락드릴게요.');
  });
})();
