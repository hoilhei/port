/* =========================================================================
   work.js — 작업물 서브페이지(work.html) 렌더링
   -------------------------------------------------------------------------
   주소창의 ?work=<slug> 값을 읽어 data.js(siteWorks)에서 해당 항목을 찾고,
   메인 페이지의 팝업과 동일한 모습(.modal-hero / .modal-body 등, styles.css에
   이미 정의됨)으로 내용을 그려줍니다.
   ========================================================================= */

(function renderWorkPage(){
  const params = new URLSearchParams(window.location.search);
  const slug = params.get('work');
  const card = document.getElementById('workPageCard');
  if(!card) return;

  const item = slug ? findWorkBySlug(slug) : null;

  if(!item){
    card.innerHTML = `
      <div class="work-page-empty">
        해당 작업물을 찾을 수 없습니다.<br>
        <a class="modal-link" href="index.html" style="margin-top:16px;">포트폴리오로 돌아가기 →</a>
      </div>
    `;
    return;
  }

  const title = item.title || item.label || '';
  const tagline = item.tagline || '';
  const tags = item.tags || [];
  const description = item.description || [];
  const features = item.features || [];
  const heroImage = item.heroImage || item.panelBg || '';

  document.title = `${title} — VOYAGER`;

  card.innerHTML = `
    <div class="modal-hero" style="background-image:url('${heroImage}')"></div>
    <div class="modal-body">
      <span class="modal-eyebrow">${item.eyebrow || ''}</span>
      <h1 class="modal-title">${title}</h1>
      <p class="modal-tagline">${tagline}</p>
      <div class="modal-tags">${tags.map(t => `<span>${t}</span>`).join('')}</div>
      <p class="modal-section-title">Overview</p>
      ${description.map(p => `<p>${p}</p>`).join('')}
      <p class="modal-section-title">Key Features</p>
      <ul>${features.map(f => `<li>${f}</li>`).join('')}</ul>
    </div>
  `;
})();
