
    // 브라우저가 새로고침 시 이전 스크롤 위치를 기억해 엉뚱한 섹션(sector-03 등)에
    // 멈춰 있는 문제를 막기 위해, 항상 맨 위(Section 1)에서 시작하도록 강제합니다.
    if('scrollRestoration' in history){ history.scrollRestoration = 'manual'; }
    window.scrollTo(0, 0);

    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* =========================================================
       인트로 프리로더 : 타이핑 + 로켓 로딩바 (동시 진행)
       ------------------------------------------------------
       ★ 문구를 바꾸려면 preloaderText 값만 수정하세요.
       ========================================================= */
    const preloaderText = "내가 가보지 못한 새로운 우주";
    const TYPE_SPEED_MS = 55; // 한 글자당 타이핑 속도
    // 로딩바가 타이핑과 정확히 같은 속도로 함께 차오르도록, 전체 소요 시간을
    // "글자 수 × 타이핑 속도"에 맞춰 자동으로 계산합니다.
    const LOAD_DURATION_MS = preloaderText.length * TYPE_SPEED_MS;

    const preloaderEl = document.getElementById('preloader');
    const typeTargetEl = document.getElementById('typeTarget');
    const loaderFillEl = document.getElementById('loaderFill');
    const loaderStarEl = document.getElementById('loaderStar');

    function typePreloaderText(){
      let charIndex = 0;
      function typeNext(){
        if(charIndex < preloaderText.length){
          typeTargetEl.textContent += preloaderText[charIndex];
          charIndex++;
          setTimeout(typeNext, TYPE_SPEED_MS);
        }
      }
      typeNext();
    }

    function runLoaderProgress(){
      const startTime = performance.now();
      function step(now){
        const elapsed = now - startTime;
        const progress = Math.min(100, (elapsed / LOAD_DURATION_MS) * 100);
        loaderFillEl.style.width = progress + '%';
        loaderStarEl.style.left = progress + '%';
        if(progress < 100){
          requestAnimationFrame(step);
        } else {
          // 로딩이 끝나면 버튼 없이 자동으로 Section 1로 이동
          setTimeout(dismissPreloader, 400);
        }
      }
      requestAnimationFrame(step);
    }

    let preloaderDismissed = false;
    function dismissPreloader(){
      if(preloaderDismissed) return; // 중복 실행 방지
      preloaderDismissed = true;
      window.scrollTo(0, 0); // 인트로 배경 미디어(Section 1)가 확실히 보이도록 최상단으로 이동
      preloaderEl.classList.add('is-hidden');
      document.body.classList.remove('preloading');
      setTimeout(() => {
        preloaderEl.style.display = 'none';
        window.scrollTo(0, 0);
        ScrollTrigger.refresh();
      }, 950);
      startIntroVideo(); // 프리로더가 사라짐과 동시에 인트로 영상 재생 시작
    }

    if(preloaderEl){
      if(reduceMotion){
        typeTargetEl.textContent = preloaderText;
        loaderFillEl.style.width = '100%';
        loaderStarEl.style.left = '100%';
        setTimeout(dismissPreloader, 400); // 모션 최소화 사용자도 자동으로 진행
      } else {
        // 타이핑과 로딩바를 같은 타이밍에 함께 시작 (따로 움직이지 않도록)
        setTimeout(() => {
          typePreloaderText();
          runLoaderProgress();
        }, 500); // 검은 화면이 잠깐 자리잡은 뒤 시작
      }
    }

    /* =========================================================
       Section 1 인트로 영상 : 재생이 끝나면 어두워지며 SECTOR-03으로 자동 스크롤
       ------------------------------------------------------
       ★ 실제 영상을 쓰려면 introBgVideo의 <source src="..."> 경로를
         assets 폴더에 넣은 실제 파일명으로 바꿔주세요.
       ========================================================= */
    const introVideoEl = document.getElementById('introBgVideo');
    const introImageEl = document.getElementById('introBgImage');
    const introDarkenEl = document.getElementById('introDarken');
    const INTRO_FALLBACK_MS = 6000; // 영상을 재생할 수 없을 때 대신 기다리는 시간
    let introEndingTriggered = false;
    let introFallbackTimer = null;

    function playIntroEnding(){
      if(introEndingTriggered) return;
      introEndingTriggered = true;
      if(introFallbackTimer) clearTimeout(introFallbackTimer);

      // 자연스럽게 어두워짐
      gsap.to([introVideoEl, introImageEl], { opacity: 0, duration: 1.4, ease: 'power2.inOut' });
      gsap.to(introDarkenEl, { opacity: 1, duration: 1.4, ease: 'power2.inOut' });

      // 어두워지는 동안 자연스럽게 SECTOR-03으로 스크롤 이동
      gsap.to(window, {
        duration: 1.6,
        delay: 0.5,
        scrollTo: { y: '#section-3', offsetY: 0 },
        ease: 'power2.inOut'
      });
    }

    function startIntroVideo(){
      if(!introVideoEl) return;
      if(reduceMotion){
        // 모션을 최소화하는 사용자에게는 영상 연출을 강제하지 않음
        return;
      }
      const playPromise = introVideoEl.play();
      if(playPromise && typeof playPromise.then === 'function'){
        playPromise.then(() => {
          // 재생 성공: 영상이 GIF 위로 자연스럽게 드러남
          gsap.to(introVideoEl, { opacity: 1, duration: 0.8, ease: 'power1.out' });
        }).catch(() => {
          // 자동재생이 막힌 경우 등: GIF만 보여주고, 일정 시간 뒤 동일한 연출로 넘어감
          introFallbackTimer = setTimeout(playIntroEnding, INTRO_FALLBACK_MS);
        });
      }
      introVideoEl.addEventListener('ended', playIntroEnding);
      introVideoEl.addEventListener('error', () => {
        introFallbackTimer = setTimeout(playIntroEnding, INTRO_FALLBACK_MS);
      });
    }

    /* =========================================================
       프로필 데이터 (Section 2)
       ------------------------------------------------------
       ★ 이 객체의 값만 바꾸면 화면이 자동으로 업데이트됩니다.
       ★ 아이콘은 아래 socialIcons 맵의 key(mail/github/linkedin/web) 중 하나를 쓰면 됩니다.
       ========================================================= */
    const profileData = {
      eyebrow: "EXPLORER LOG",
      name: "YOUR NAME",
      role: "FRONTEND DEVELOPER · CREATIVE CODER",

      // 왼쪽 메뉴 리스트 (target은 클릭했을 때 반응할 오른쪽/왼쪽 창의 id)
      menu: [
        { icon: "◎", title: "ABOUT ME",   sub: "저를 소개합니다",   active: true, target: "profileStat"   },
        { icon: "✎", title: "SKILLS",     sub: "사용하는 기술",                   target: "profileSkills" },
        { icon: "🗂", title: "EXPERIENCE", sub: "지나온 경력",                    target: "profileQuote"  },
        { icon: "✉", title: "CONTACT",    sub: "연락하기",                       target: "profileSocial" }
      ],

      // 왼쪽 하단 소개 카드
      quote: {
        image: "images/profile-quote.jpg",
        title: "EXPLORE. CREATE. BUILD.",
        desc: "사용자 경험과 인터랙션의 경계를 탐험하는 프론트엔드 개발자입니다."
      },

      // 오른쪽 상단 스탯 카드
      stat: {
        avatarInitial: "YN",
        playerLabel: "YOUR NAME",
        roleLabel: "Frontend Explorer",
        level: 5,
        xpCurrent: 3200,
        xpMax: 5000
      },

      // 오른쪽 스킬 카드 (0~100 사이 값)
      skills: [
        { name: "React / TypeScript",     value: 90 },
        { name: "UI 애니메이션 (GSAP)",    value: 85 },
        { name: "3D / WebGL",             value: 60 },
        { name: "디자인 시스템",           value: 75 }
      ],
      achievement: "최근 성취 · OOO 프로젝트 런칭 (+500 XP)",

      // 소셜 링크 (icon: mail / github / linkedin / web 중 선택)
      social: [
        { icon: "mail",     href: "mailto:you@example.com" },
        { icon: "github",   href: "https://github.com/yourid" },
        { icon: "linkedin", href: "https://linkedin.com/in/yourid" },
        { icon: "web",      href: "https://yourwebsite.com" }
      ]
    };

    const socialIcons = {
      mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>',
      github: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1.1-.3-3.5 1.3a12.3 12.3 0 0 0-6.2 0C6.5 3.7 5.4 4 5.4 4a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 10.4c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2V22"/></svg>',
      linkedin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 10v7M7 7v.01M12 17v-4a2 2 0 0 1 4 0v4M12 13v4"/></svg>',
      web: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>'
    };

    function renderProfile(data){
      document.getElementById('profileEyebrow').textContent = data.eyebrow;
      document.getElementById('profileName').textContent = data.name;
      document.getElementById('profileRole').textContent = data.role;

      // 메뉴
      const menuEl = document.getElementById('profileMenu');
      menuEl.innerHTML = data.menu.map(item => `
        <li class="menu-item${item.active ? ' active' : ''}" data-target="${item.target || ''}">
          <span class="menu-icon">${item.icon}</span>
          <span class="menu-text">
            <span class="menu-title">${item.title}</span>
            <span class="menu-sub">${item.sub}</span>
          </span>
        </li>
      `).join('');

      // 소개 카드
      const quoteEl = document.getElementById('profileQuote');
      quoteEl.innerHTML = `
        <div class="quote-bg" style="background-image:url('${data.quote.image}')"></div>
        <div class="quote-body">
          <p class="quote-title">${data.quote.title}</p>
          <p class="quote-desc">${data.quote.desc}</p>
        </div>
      `;

      // 스탯 카드
      const statEl = document.getElementById('profileStat');
      const xpPct = Math.min(100, Math.round((data.stat.xpCurrent / data.stat.xpMax) * 100));
      statEl.innerHTML = `
        <div class="stat-header">
          <div class="avatar-badge">${data.stat.avatarInitial}</div>
          <div class="stat-name-block">
            <span class="stat-name">${data.stat.playerLabel}</span>
            <span class="stat-role">${data.stat.roleLabel}</span>
            <span class="stat-level">LEVEL ${String(data.stat.level).padStart(2,'0')}</span>
          </div>
        </div>
        <div class="xp-bar"><div class="xp-fill" style="width:${xpPct}%"></div></div>
        <span class="xp-label">${data.stat.xpCurrent.toLocaleString()} / ${data.stat.xpMax.toLocaleString()} XP</span>
      `;

      // 스킬 카드
      const skillsEl = document.getElementById('profileSkills');
      skillsEl.innerHTML = `
        <span class="card-heading">CURRENT FOCUS</span>
        <ul class="skill-list">
          ${data.skills.map(s => `
            <li class="skill-row">
              <div class="skill-top"><span>${s.name}</span><span>${s.value}%</span></div>
              <div class="skill-bar"><div class="skill-fill" style="width:${s.value}%"></div></div>
            </li>
          `).join('')}
        </ul>
        <div class="achievement-line">★ ${data.achievement}</div>
      `;

      // 소셜 링크
      const socialEl = document.getElementById('profileSocial');
      socialEl.innerHTML = data.social.map(s => `
        <a class="social-btn" href="${s.href}" target="_blank" rel="noopener">${socialIcons[s.icon] || ''}</a>
      `).join('');
    }

    renderProfile(profileData);

    /* ---------- 왼쪽 메뉴 클릭 → 대응하는 창(오른쪽/왼쪽 카드) 반응 효과 ---------- */
    (function bindProfileMenu(){
      const menuItems = document.querySelectorAll('#profileMenu .menu-item');
      if(!menuItems.length) return;

      function setActiveMenu(selectedItem){
        menuItems.forEach(item => {
          const isSelected = item === selectedItem;
          item.classList.toggle('active', isSelected);
          const targetEl = document.getElementById(item.dataset.target);
          if(targetEl) targetEl.classList.toggle('panel-highlight', isSelected);
        });
      }

      menuItems.forEach(item => {
        item.addEventListener('click', () => setActiveMenu(item));
      });

      // 처음 로드 시, active로 표시된 메뉴의 대응 창도 함께 하이라이트
      const initialActive = document.querySelector('#profileMenu .menu-item.active') || menuItems[0];
      setActiveMenu(initialActive);
    })();

    /* ---------- 푸터 : 소셜 아이콘 렌더링 + 구독 폼 ---------- */
    const footerSocialsEl = document.getElementById('footerSocials');
    if(footerSocialsEl){
      // profileData.social과 동일한 아이콘 세트를 재사용합니다 (mail/github/linkedin/web)
      const footerSocialLinks = [
        { icon: "mail",     href: "mailto:you@example.com" },
        { icon: "github",   href: "https://github.com/yourid" },
        { icon: "linkedin", href: "https://linkedin.com/in/yourid" },
        { icon: "web",      href: "https://yourwebsite.com" }
      ];
      footerSocialsEl.innerHTML = footerSocialLinks.map(s => `
        <a class="social-btn" href="${s.href}" target="_blank" rel="noopener">${socialIcons[s.icon] || ''}</a>
      `).join('');
    }

    const footerSubscribeForm = document.getElementById('footerSubscribeForm');
    if(footerSubscribeForm){
      footerSubscribeForm.addEventListener('submit', (e) => {
        e.preventDefault(); // 실제 구독 처리 로직은 추후 연결 예정
        const input = document.getElementById('footerEmailInput');
        if(input) input.value = '';
      });
    }

    /* ---------- 별 생성 (box-shadow 트릭) ---------- */
    function generateStars(el, count, color){
      const w = window.innerWidth * 1.3;
      const h = window.innerHeight * 1.3;
      let shadows = [];
      for(let i=0;i<count;i++){
        const x = Math.round(Math.random()*w);
        const y = Math.round(Math.random()*h);
        const size = Math.random() > 0.85 ? '2px' : '1px';
        shadows.push(`${x}px ${y}px 0 ${size==='2px'?'1px':'0'} ${color}`);
      }
      el.style.boxShadow = shadows.join(',');
      el.style.width = size2(1);
      el.style.height = size2(1);
    }
    function size2(v){ return v+'px'; }

    generateStars(document.getElementById('stars-1'), 140, 'rgba(255,247,224,0.75)');
    generateStars(document.getElementById('stars-2'), 140, 'rgba(210,255,248,0.7)');
    generateStars(document.getElementById('stars-3'), 140, 'rgba(200,240,220,0.72)');
    generateStars(document.getElementById('stars-4'), 140, 'rgba(200,225,255,0.75)');
    generateStars(document.getElementById('stars-5'), 140, 'rgba(255,224,200,0.7)');
    generateStars(document.getElementById('stars-6'), 140, 'rgba(232,210,255,0.7)');

    /* ---------- 배경 전환 (크로스페이드) ---------- */
    const sectionCount = 6;
    const dots = gsap.utils.toArray('.dot');

    function setActive(index){
      gsap.utils.toArray('.bg-layer').forEach((layer, i) => {
        gsap.to(layer, { opacity: (i === index-1) ? 1 : 0, duration: 1.3, ease: 'power2.inOut' });
      });
      dots.forEach((d, i) => d.classList.toggle('active', i === index-1));
    }

    for(let i=1;i<=sectionCount;i++){
      const section = document.getElementById(`section-${i}`);
      const bgInner = document.querySelector(`#bg-${i} .bg-inner`);

      // 배경 줌인 (scrub 기반 스케일업)
      if(!reduceMotion){
        gsap.fromTo(bgInner,
          { scale: 1 },
          {
            scale: 1.18,
            ease: 'none',
            scrollTrigger:{
              trigger: section,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true
            }
          }
        );
      }

      // 섹션 진입 시 배경 크로스페이드 전환
      ScrollTrigger.create({
        trigger: section,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => setActive(i),
        onEnterBack: () => setActive(i)
      });

      // 프로필 그리드 등장 애니메이션 (Section 2)
      const profileGrid = section.querySelector('.profile-grid');
      if(profileGrid){
        gsap.fromTo(profileGrid,
          { opacity: 0, y: 40 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: profileGrid,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // 아코디언 등장 애니메이션 (Section 5)
      const accordion = section.querySelector('.accordion');
      if(accordion){
        gsap.fromTo(accordion,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: accordion,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // 수직 순환 캐러셀 등장 애니메이션 (Section 4)
      const vStage = section.querySelector('.vcarousel-stage');
      if(vStage){
        gsap.fromTo(vStage,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: vStage,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // 브랜드 엘리먼트 팬 카드 등장 애니메이션 (Section 3)
      const fanStage = section.querySelector('.fan-stage');
      if(fanStage){
        gsap.fromTo(fanStage,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: fanStage,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    }

    /* ---------- 우측 내비게이션 클릭 ---------- */
    dots.forEach(dot => {
      dot.addEventListener('click', () => {
        gsap.to(window, {
          duration: 1.1,
          scrollTo: { y: `#${dot.dataset.target}`, offsetY: 0 },
          ease: 'power2.inOut'
        });
      });
    });

    /* =========================================================
       아코디언 워크 카드 (Section 6 · 네뷸러 차원)
       ------------------------------------------------------
       ★ 내용은 data.js의 siteWorks.accordion 배열에서 관리합니다.
       ========================================================= */
    function renderAccordion(){
      const accordionEl = document.getElementById('workAccordion');
      if(!accordionEl) return;
      accordionEl.innerHTML = siteWorks.accordion.map((item, i) => `
        <a class="panel${i === 1 ? ' active' : ''}" href="${workLink(item.slug)}" data-index="${i}">
          <div class="panel-bg" style="background-image:url('${item.panelBg || item.heroImage}')"></div>
          <div class="panel-overlay"></div>
          <span class="panel-label">${item.label}</span>
          <div class="panel-content">
            <p class="panel-desc">${item.tagline}</p>
            <span class="panel-cta">자세히 보기 →</span>
          </div>
          <span class="panel-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">${item.icon || ''}</svg>
          </span>
        </a>
      `).join('');
    }
    renderAccordion();

    /* ---------- 워크 아코디언 : 터치 기기 탭-확장 처리 ---------- */
    const panels = document.querySelectorAll('.panel');
    const hasHover = window.matchMedia('(hover: hover)').matches;

    panels.forEach(panel => {
      panel.addEventListener('click', (e) => {
        if(!hasHover && !panel.classList.contains('active')){
          // 터치 기기: 첫 탭은 카드 확장만, 두 번째 탭에서 실제 이동
          e.preventDefault();
          panels.forEach(p => p.classList.remove('active'));
          panel.classList.add('active');
        }
        // hasHover(데스크톱) 환경에서는 기본 링크 동작으로 바로 이동
      });
    });

    /* =========================================================
       회전 캐러셀 워크 데이터 (Section 5 · 잔광 차원)
       ------------------------------------------------------
       ★ 내용은 data.js의 siteWorks.carousel 배열에서 관리합니다.
         (메인 카드 / 팝업 / 서브페이지가 모두 이 데이터를 함께 사용합니다)
       ========================================================= */
    const carouselProjects = siteWorks.carousel;

    /* ---------- 캐러셀 카드 생성 ---------- */
    const carouselRing = document.getElementById('carouselRing');
    const carouselStage = document.getElementById('carouselStage');
    const angleStep = 360 / carouselProjects.length;
    const carouselRadius = 320;

    carouselProjects.forEach((proj, i) => {
      const angle = i * angleStep;
      const card = document.createElement('div');
      card.className = 'carousel-card';
      card.style.transform = `rotateY(${angle}deg) translateZ(${carouselRadius}px)`;
      card.innerHTML = `
        <div class="card-face card-front">
          <div class="card-bg" style="background-image:url('${proj.heroImage}')"></div>
          <div class="card-shade"></div>
          <span class="card-label">${proj.eyebrow}<br>${proj.title}</span>
          <span class="card-cta">작업 보기 →</span>
        </div>
        <div class="card-face card-back">
          <span class="back-index">${proj.eyebrow}</span>
          <span class="back-ring"></span>
          <span class="back-caption">회전 중입니다<br>정면으로 오면 자세히 볼 수 있어요</span>
        </div>
      `;
      card.addEventListener('click', (e) => {
        if(carouselDragDistance > 6) return; // 드래그 후 발생하는 클릭은 무시
        if(card.classList.contains('is-front') && e.target.closest('.card-cta')){
          openWorkModal(proj);
        }
      });
      carouselRing.appendChild(card);
    });

    /* ---------- 캐러셀 회전 (아주 천천히 왼쪽으로) ---------- */
    let carouselRotation = 0;
    let carouselPaused = false;
    let carouselLastTime = null;
    const CAROUSEL_TURN_MS = 90000; // 한 바퀴 도는 데 걸리는 시간(ms) - 클수록 더 느리게 회전
    const CAROUSEL_SPEED = 360 / CAROUSEL_TURN_MS;

    function normalizeAngle(a){
      a = a % 360;
      if(a > 180) a -= 360;
      if(a < -180) a += 360;
      return a;
    }

    function updateFrontCard(){
      let frontCard = null;
      let minAbs = Infinity;
      Array.from(carouselRing.children).forEach((card, i) => {
        const angle = normalizeAngle(i * angleStep + carouselRotation);
        const absAngle = Math.abs(angle);
        if(absAngle < minAbs){ minAbs = absAngle; frontCard = card; }
      });
      Array.from(carouselRing.children).forEach(card => {
        card.classList.toggle('is-front', card === frontCard);
      });
    }

    function animateCarousel(time){
      if(carouselLastTime === null) carouselLastTime = time;
      const delta = time - carouselLastTime;
      carouselLastTime = time;
      if(!carouselPaused && !reduceMotion){
        carouselRotation -= delta * CAROUSEL_SPEED; // 음수 방향 = 왼쪽으로 회전
        carouselRing.style.transform = `rotateY(${carouselRotation}deg)`;
      }
      updateFrontCard();
      requestAnimationFrame(animateCarousel);
    }
    requestAnimationFrame(animateCarousel);

    if(carouselStage){
      carouselStage.addEventListener('mouseenter', () => { carouselPaused = true; });
      carouselStage.addEventListener('mouseleave', () => { if(!carouselDragging) carouselPaused = false; });
    }

    /* ---------- 드래그로 캐러셀 직접 회전 ---------- */
    let carouselDragging = false;
    let carouselDragStartX = 0;
    let carouselDragStartRotation = 0;
    let carouselDragDistance = 0;
    const DRAG_SENSITIVITY = 0.35; // 1px 드래그당 회전하는 각도

    if(carouselStage){
      carouselStage.addEventListener('pointerdown', (e) => {
        carouselDragging = true;
        carouselDragDistance = 0;
        carouselDragStartX = e.clientX;
        carouselDragStartRotation = carouselRotation;
        carouselPaused = true;
        carouselStage.classList.add('is-dragging');
        carouselStage.setPointerCapture(e.pointerId);
      });

      carouselStage.addEventListener('pointermove', (e) => {
        if(!carouselDragging) return;
        const deltaX = e.clientX - carouselDragStartX;
        carouselDragDistance = Math.abs(deltaX);
        carouselRotation = carouselDragStartRotation + deltaX * DRAG_SENSITIVITY;
        carouselRing.style.transform = `rotateY(${carouselRotation}deg)`;
        updateFrontCard();
      });

      const endCarouselDrag = () => {
        if(!carouselDragging) return;
        carouselDragging = false;
        carouselStage.classList.remove('is-dragging');
        if(!carouselStage.matches(':hover')) carouselPaused = false;
      };
      carouselStage.addEventListener('pointerup', endCarouselDrag);
      carouselStage.addEventListener('pointercancel', endCarouselDrag);
      carouselStage.addEventListener('pointerleave', endCarouselDrag);
    }

    /* =========================================================
       브랜드 엘리먼트 카드 (Section 3 · 에테르 차원)
       ------------------------------------------------------
       ★ 내용은 data.js의 siteWorks.fan 배열에서 관리합니다.
       ★ 동작: 평소엔 7장이 화면 전체에 사선으로 길게 겹쳐 있다가
              → 영역에 호버하면 일렬로 펼쳐지고
              → interactive:true 인 카드는 호버 시 카드 전체가 위로 떠오르며
                "이동하기" 버튼이 뜨고, 클릭하면 해당 서브페이지로 이동합니다.
              → interactive:false 인 카드는 장식용으로, 버튼 없이 리프트만 됩니다.
       ========================================================= */
    const fanCards = siteWorks.fan;

    const fanStage = document.querySelector('.fan-stage');
    const fanRow = document.getElementById('fanRow');

    if(fanRow && fanStage){
      const n = fanCards.length;
      const centerOffset = (n - 1) / 2;

      // 겹쳐진 초기 상태: 화면 전체를 가로지르는 긴 사선으로 배치 (간격을 넓게)
      const stackStepXvw = 9.5;   // 카드 사이 가로 간격 (뷰포트 폭 기준 - 화면 크기에 비례해 항상 전체 폭을 사용)
      const stackStepY = 46;      // 카드 사이 세로 간격(px, 아래→위로 상승)
      // 펼쳐진 상태 (일렬로, 카드 사이 간격을 넓게)
      const spreadSpacing = 232;

      fanCards.forEach((data, i) => {
        const isInteractive = !!data.interactive;
        const card = document.createElement('div');
        card.className = `fan-card ${data.type}${isInteractive ? ' is-interactive' : ''}`;
        // 왼쪽 아래(인덱스가 작은 카드)가 가장 앞장, 오른쪽 위(인덱스가 큰 카드)가 가장 뒷장이 되도록 z-index 반전
        card.style.zIndex = String(10 + (n - 1 - i));

        const stackXvw = (i - centerOffset) * stackStepXvw;
        const stackY = -(i - centerOffset) * stackStepY;
        const stackOpacity = 0.5 + (i / (n - 1)) * 0.5;

        // 카드가 화면과 수직/수평으로 반듯하게 서도록 회전 없이 위치만 이동
        card.style.setProperty('--stack-transform',
          `translate(${stackXvw}vw, ${stackY}px) rotate(0deg)`);
        card.style.setProperty('--stack-opacity', String(stackOpacity));

        const spreadX = (i - centerOffset) * spreadSpacing;
        card.style.setProperty('--spread-transform',
          `translate(${spreadX}px, 0px) rotate(0deg) scale(1)`);

        let inner = '';
        if(data.type === 'fan-stat'){
          inner = `
            <div>
              <p class="fan-stat-number">${data.label}</p>
              <div class="fan-bar"></div>
            </div>
          `;
        } else if(data.type === 'fan-pill'){
          inner = `<span class="fan-pill-tag">${data.label}</span>`;
        } else if(data.type === 'fan-shadow'){
          inner = `<div class="fan-glow-pill"></div>`;
        } else if(data.type === 'fan-metaphor'){
          inner = `<div><div class="fan-metaphor-shape"></div><span class="fan-label">${data.label}</span></div>`;
        } else if(data.type === 'fan-blank'){
          inner = '';
        } else {
          inner = `<span class="fan-label">${data.label}</span>`;
        }

        // 카드 안에 이미지/영상이 지정되어 있으면 배경 미디어 레이어를 만들어 내용 뒤에 깔아줌
        let mediaHTML = '';
        if(data.media && data.media.src){
          if(data.media.type === 'video'){
            mediaHTML = `
              <video class="fan-card-media" autoplay loop muted playsinline
                     onerror="this.remove()">
                <source src="${data.media.src}" type="video/mp4">
              </video>
              <div class="fan-card-media-tint"></div>
            `;
          } else {
            mediaHTML = `
              <img class="fan-card-media" src="${data.media.src}" alt="" onerror="this.remove()">
              <div class="fan-card-media-tint"></div>
            `;
          }
        }

        card.innerHTML = `
          <div class="fan-card-lift">
            ${mediaHTML}
            ${inner}
            ${isInteractive ? `<a class="fan-cta" href="${workLink(data.slug)}">이동하기 →</a>` : ''}
          </div>
        `;

        fanRow.appendChild(card);
      });

      // 카드 영역에 마우스가 올라오면 겹쳐진 카드들이 일렬로 펼쳐짐
      fanStage.addEventListener('mouseenter', () => { fanStage.classList.add('is-spread'); });
      fanStage.addEventListener('mouseleave', () => { fanStage.classList.remove('is-spread'); });
    }

    /* =========================================================
       수직 순환 카드 캐러셀 (Section 4 · 오르빗 차원)
       ------------------------------------------------------
       ★ 내용은 data.js의 siteWorks.vcarousel 배열에서 관리합니다.
       ========================================================= */
    const vcarouselProjects = siteWorks.vcarousel;

    const vcarouselRing = document.getElementById('vcarouselRing');
    const vcarouselStage = document.getElementById('vcarouselStage');
    const vAngleStep = 360 / vcarouselProjects.length;
    const vRadius = 240;

    vcarouselProjects.forEach((proj, i) => {
      const angle = i * vAngleStep;
      const card = document.createElement('div');
      card.className = 'vcarousel-card';
      card.style.transform = `rotateX(${angle}deg) translateZ(${vRadius}px)`;
      card.innerHTML = `
        <div class="vcard-thumb" style="background:${proj.gradient}"></div>
        <div class="vcard-shade"></div>
        <span class="vcard-number">${proj.number}</span>
        <div class="vcard-text">
          <p class="vcard-title">${proj.title}</p>
          <p class="vcard-sub">${proj.sub}</p>
        </div>
        <span class="vcard-cta">이동하기 →</span>
      `;
      const cta = card.querySelector('.vcard-cta');
      cta.addEventListener('click', (e) => {
        if(vDragDistance > 6) return; // 드래그 후 발생하는 클릭은 무시
        if(card.classList.contains('is-front')){
          openWorkModal(proj); // 상세 내용을 팝업으로 표시
        }
      });
      // 카드 "모양" 위에 마우스가 있을 때만 회전을 멈추고, 주변(빈 공간)에서는 계속 회전
      card.addEventListener('mouseenter', () => { vPaused = true; });
      card.addEventListener('mouseleave', () => { if(!vDragging) vPaused = false; });
      vcarouselRing.appendChild(card);
    });

    /* ---------- 수직 회전 (위에서 아래로 흐르며 원을 그리며 순환) ---------- */
    let vRotation = 0;
    let vPaused = false;
    let vLastTime = null;
    const VCAROUSEL_TURN_MS = 39000; // 한 바퀴 도는 데 걸리는 시간(ms) - 기존 대비 50% 더 느리게
    const V_SPEED = 360 / VCAROUSEL_TURN_MS;

    function updateFrontCardV(){
      let frontCard = null;
      let minAbs = Infinity;
      Array.from(vcarouselRing.children).forEach((card, i) => {
        const angle = normalizeAngle(i * vAngleStep + vRotation);
        const absAngle = Math.abs(angle);
        if(absAngle < minAbs){ minAbs = absAngle; frontCard = card; }
      });
      Array.from(vcarouselRing.children).forEach(card => {
        card.classList.toggle('is-front', card === frontCard);
      });
    }

    function animateVCarousel(time){
      if(vLastTime === null) vLastTime = time;
      const delta = time - vLastTime;
      vLastTime = time;
      if(!vPaused && !reduceMotion){
        vRotation += delta * V_SPEED; // 양수 방향 = 위→아래로 흐르는 방향
        vcarouselRing.style.transform = `rotateX(${vRotation}deg)`;
      }
      updateFrontCardV();
      requestAnimationFrame(animateVCarousel);
    }
    requestAnimationFrame(animateVCarousel);

    if(vcarouselStage){
      vcarouselStage.addEventListener('mouseenter', () => { vPaused = true; });
      vcarouselStage.addEventListener('mouseleave', () => { if(!vDragging) vPaused = false; });
    }

    /* ---------- 드래그로 카드 위/아래 이동 ---------- */
    let vDragging = false;
    let vDragStartY = 0;
    let vDragStartRotation = 0;
    let vDragDistance = 0;
    const V_DRAG_SENSITIVITY = 0.35; // 1px 드래그당 회전하는 각도

    if(vcarouselStage){
      vcarouselStage.addEventListener('pointerdown', (e) => {
        vDragging = true;
        vDragDistance = 0;
        vDragStartY = e.clientY;
        vDragStartRotation = vRotation;
        vPaused = true;
        vcarouselStage.classList.add('is-dragging');
        vcarouselStage.setPointerCapture(e.pointerId);
      });

      vcarouselStage.addEventListener('pointermove', (e) => {
        if(!vDragging) return;
        const deltaY = e.clientY - vDragStartY;
        vDragDistance = Math.abs(deltaY);
        vRotation = vDragStartRotation + deltaY * V_DRAG_SENSITIVITY;
        vcarouselRing.style.transform = `rotateX(${vRotation}deg)`;
        updateFrontCardV();
      });

      const endVDrag = () => {
        if(!vDragging) return;
        vDragging = false;
        vcarouselStage.classList.remove('is-dragging');
        if(!vcarouselStage.matches(':hover')) vPaused = false;
      };
      vcarouselStage.addEventListener('pointerup', endVDrag);
      vcarouselStage.addEventListener('pointercancel', endVDrag);
      vcarouselStage.addEventListener('pointerleave', endVDrag);
    }

    /* ---------- 작업물 상세 팝업 ---------- */
    const workModalOverlay = document.getElementById('workModalOverlay');
    const workModalClose = document.getElementById('workModalClose');
    const modalHero = document.getElementById('modalHero');
    const modalBody = document.getElementById('modalBody');

    function openWorkModal(proj){
      modalHero.style.backgroundImage = `url('${proj.heroImage}')`;
      modalBody.innerHTML = `
        <span class="modal-eyebrow">${proj.eyebrow}</span>
        <h2 class="modal-title">${proj.title}</h2>
        <p class="modal-tagline">${proj.tagline}</p>
        <div class="modal-tags">${proj.tags.map(t => `<span>${t}</span>`).join('')}</div>
        <p class="modal-section-title">Overview</p>
        ${proj.description.map(p => `<p>${p}</p>`).join('')}
        <p class="modal-section-title">Key Features</p>
        <ul>${proj.features.map(f => `<li>${f}</li>`).join('')}</ul>
        <a class="modal-link" href="${workLink(proj.slug)}">자세히 보기 →</a>
      `;
      workModalOverlay.classList.add('open');
      workModalOverlay.querySelector('.modal-box').scrollTop = 0;
      document.body.style.overflow = 'hidden';
      carouselPaused = true;
    }

    function closeWorkModal(){
      workModalOverlay.classList.remove('open');
      document.body.style.overflow = '';
    }

    if(workModalClose) workModalClose.addEventListener('click', closeWorkModal);
    if(workModalOverlay){
      workModalOverlay.addEventListener('click', (e) => {
        if(e.target === workModalOverlay) closeWorkModal();
      });
    }
    document.addEventListener('keydown', (e) => {
      if(e.key === 'Escape') closeWorkModal();
    });

    window.addEventListener('resize', () => {
      generateStars(document.getElementById('stars-1'), 140, 'rgba(255,247,224,0.75)');
      generateStars(document.getElementById('stars-2'), 140, 'rgba(210,255,248,0.7)');
      generateStars(document.getElementById('stars-3'), 140, 'rgba(200,240,220,0.72)');
      generateStars(document.getElementById('stars-4'), 140, 'rgba(200,225,255,0.75)');
      generateStars(document.getElementById('stars-5'), 140, 'rgba(255,224,200,0.7)');
      generateStars(document.getElementById('stars-6'), 140, 'rgba(232,210,255,0.7)');
      ScrollTrigger.refresh();
    });
  