/* =========================================================================
   data.js — 사이트 전체에서 공유하는 콘텐츠 데이터
   -------------------------------------------------------------------------
   이 파일 하나만 수정하면 메인 페이지의 각 섹션 카드와, 카드를 클릭했을 때
   열리는 서브페이지(work.html)의 내용이 동시에 바뀝니다.

   각 작업물 항목에 slug를 넣어두면:
     - 메인 페이지 카드의 버튼(이동하기 / 작업 보기 / 자세히 보기)이
       work.html?work=<slug> 로 연결되거나, 팝업에서 "사이트 방문하기"
       링크로 연결됩니다.
     - work.html은 주소의 slug 값으로 이 배열에서 내용을 찾아 보여줍니다.

   ★ 텍스트 / 이미지 / 영상 교체: 아래 값들만 실제 내용으로 바꾸면 됩니다.
   ========================================================================= */

const siteWorks = {

  /* ---------- Section 3 · 에테르 차원 (겹침→펼침 팬 카드) ----------
     interactive: true 인 카드만 "이동하기" 버튼 + 서브페이지가 생깁니다.
     media: { type:"image"|"video", src:"..." } 로 카드 안에 이미지/영상 삽입 가능. */
  fan: [
    { type: "fan-blank", label: "Floating Edges", interactive: false },

    { type: "fan-paper", label: "Paper", interactive: true, slug: "paper-texture",
      eyebrow: "WORK · 031", heroImage: "images/work-paper-texture.jpg",
      tagline: "질감과 여백만으로 완성한 미니멀 브랜드 스타일 가이드입니다.",
      tags: ["Style Guide", "Print", "Texture"],
      description: [
        "종이 질감과 여백을 중심으로 브랜드의 톤을 표현한 스타일 가이드 프로젝트입니다.",
        "디지털과 인쇄 매체 모두에서 일관된 질감을 유지하도록 설계했습니다."
      ],
      features: ["종이 질감 텍스처 시스템", "인쇄/디지털 겸용 가이드", "여백 기반 그리드"] },

    { type: "fan-pill", label: "Glass Window", interactive: true, slug: "glass-window",
      eyebrow: "WORK · 032", heroImage: "images/work-glass-window.jpg",
      tagline: "반투명 유리 질감의 UI 컴포넌트 시스템입니다.",
      tags: ["UI Kit", "Glassmorphism", "Design System"],
      description: [
        "반투명한 유리창 같은 레이어링을 재사용 가능한 컴포넌트로 정리한 UI 키트입니다.",
        "다양한 배경 위에서도 가독성을 유지하도록 블러/명도 값을 세밀하게 조정했습니다."
      ],
      features: ["재사용 가능한 글래스 컴포넌트", "배경 대응 명도 자동 보정", "Figma 라이브러리 제공"] },

    { type: "fan-blur", label: "Image Blurs", interactive: true, slug: "image-blurs",
      eyebrow: "WORK · 033", heroImage: "images/work-image-blurs.jpg",
      media: { type: "image", src: "images/fan-image-blurs.jpg" },
      tagline: "이미지를 흐릿하게 번지듯 표현한 인터랙션 실험입니다.",
      tags: ["Motion", "WebGL", "Experiment"],
      description: [
        "이미지가 스크롤/호버에 따라 부드럽게 번지고 다시 또렷해지는 인터랙션을 실험한 프로젝트입니다.",
        "실시간 블러 연산을 최적화해 저사양 기기에서도 자연스럽게 동작하도록 만들었습니다."
      ],
      features: ["실시간 블러 트랜지션", "스크롤 연동 포커스 효과", "성능 최적화된 셰이더"] },

    { type: "fan-shadow", label: "Reflected Shadow", interactive: true, slug: "reflected-shadow",
      eyebrow: "WORK · 034", heroImage: "images/work-reflected-shadow.jpg",
      tagline: "빛과 그림자의 반사를 활용한 제품 프레젠테이션입니다.",
      tags: ["Product", "Lighting", "3D"],
      description: [
        "제품 아래에 반사되는 은은한 빛을 활용해 고급스러운 분위기를 연출한 프레젠테이션 페이지입니다.",
        "실제 촬영 없이도 조명 연출만으로 프리미엄한 톤을 표현했습니다."
      ],
      features: ["반사광 연출 컴포넌트", "다크모드 전용 프레젠테이션", "제품 하이라이트 애니메이션"] },

    { type: "fan-stat", label: "48%", interactive: false },
    { type: "fan-metaphor", label: "Visual Metaphors", interactive: false,
      media: { type: "video", src: "images/fan-visual-metaphors.mp4" } }
  ],

  /* ---------- Section 4 · 오르빗 차원 (수직 순환 캐러셀) ---------- */
  vcarousel: [
    { number: "01", title: "Signal Drift", sub: "Web App", slug: "signal-drift",
      gradient: "linear-gradient(135deg, #12324f, #6fe7dc)",
      eyebrow: "WORK · 021", heroImage: "images/vwork-01-signal-drift.jpg",
      tagline: "실시간 위성 신호를 시각화한 모니터링 웹 애플리케이션입니다.",
      tags: ["Web App", "Real-time", "Data Viz"],
      description: [
        "여러 위성에서 수신되는 신호 세기와 궤도 데이터를 실시간으로 모니터링할 수 있는 대시보드형 웹 앱입니다.",
        "이상 신호가 감지되면 즉시 알림이 표시되도록 설계했습니다."
      ],
      features: ["실시간 신호 스트리밍 차트", "이상 감지 알림", "다중 위성 비교 뷰"] },

    { number: "02", title: "Inner Cycle", sub: "Desktop", slug: "inner-cycle",
      gradient: "linear-gradient(135deg, #3a1f14, #ff9b5c)",
      eyebrow: "WORK · 022", heroImage: "images/vwork-02-inner-cycle.jpg",
      tagline: "개인의 리듬을 기록하고 시각화하는 데스크톱 애플리케이션입니다.",
      tags: ["Desktop App", "Electron", "Personal Data"],
      description: [
        "수면, 집중, 휴식 사이클을 기록해 하루의 리듬을 한눈에 보여주는 데스크톱 앱입니다.",
        "미니멀한 UI로 데이터를 계기판처럼 직관적으로 표현했습니다."
      ],
      features: ["일간/주간 리듬 시각화", "커스텀 알림 스케줄", "로컬 데이터 저장"] },

    { number: "03", title: "Halo Market", sub: "E-commerce", slug: "halo-market",
      gradient: "linear-gradient(135deg, #241238, #c97bff)",
      eyebrow: "WORK · 023", heroImage: "images/vwork-03-halo-market.jpg",
      tagline: "한정판 컬렉션을 위한 몰입형 이커머스 웹사이트입니다.",
      tags: ["E-commerce", "3D", "Checkout UX"],
      description: [
        "제품을 은은한 빛의 고리(halo)로 강조해 보여주는 프리미엄 이커머스 사이트입니다.",
        "구매 전환을 위해 결제 단계를 최소화했습니다."
      ],
      features: ["제품 하이라이트 애니메이션", "간소화된 원페이지 체크아웃", "재고 실시간 반영"] },

    { number: "04", title: "Nova Studio", sub: "Branding", slug: "nova-studio",
      gradient: "linear-gradient(135deg, #3a2a10, #f3c77a)",
      eyebrow: "WORK · 024", heroImage: "images/vwork-04-nova-studio.jpg",
      tagline: "신생 스튜디오를 위한 브랜드 아이덴티티 & 웹사이트입니다.",
      tags: ["Branding", "Identity", "Motion"],
      description: [
        "빛나는 별(nova)의 이미지를 모티브로 브랜드의 로고, 컬러 시스템, 웹사이트를 함께 설계했습니다.",
        "브랜드 무드에 맞춘 타이포그래피와 모션 가이드도 함께 제작했습니다."
      ],
      features: ["로고 & 컬러 시스템", "브랜드 웹사이트", "모션 아이덴티티 가이드"] },

    { number: "05", title: "Quiet Orbit", sub: "Landing Page", slug: "quiet-orbit",
      gradient: "linear-gradient(135deg, #16233a, #7fc4ff)",
      eyebrow: "WORK · 025", heroImage: "images/vwork-05-quiet-orbit.jpg",
      tagline: "차분한 톤으로 제품을 소개하는 원페이지 랜딩입니다.",
      tags: ["Landing Page", "GSAP", "Minimal"],
      description: [
        "궤도를 도는 별처럼, 스크롤에 따라 제품의 기능이 차분하게 하나씩 드러나는 랜딩 페이지입니다.",
        "과하지 않은 모션으로 정보 전달에 집중했습니다."
      ],
      features: ["스크롤 기반 스토리텔링", "절제된 모션 연출", "반응형 타이포그래피"] }
  ],

  /* ---------- Section 5 · 잔광 차원 (원형 회전 캐러셀) ---------- */
  carousel: [
    { title: "오로라 오케스트레이션", slug: "aurora-orchestration",
      eyebrow: "WORK · 011", heroImage: "images/carousel-work-01-aurora.jpg",
      tagline: "실시간 위성 데이터를 오로라처럼 흐르는 대시보드로 시각화한 프로젝트입니다.",
      tags: ["Data Viz", "D3.js", "WebSocket"],
      description: [
        "우주 관측소에서 수집되는 실시간 데이터를 초 단위로 갱신되는 대시보드로 재구성했습니다.",
        "복잡한 수치를 오로라의 흐름처럼 자연스러운 곡선과 색상 변화로 표현해 직관적으로 읽히도록 설계했습니다."
      ],
      features: ["실시간 WebSocket 데이터 스트리밍", "커스텀 D3.js 시각화 컴포넌트", "다크모드 전용 컬러 시스템"] },

    { title: "이클립스 커머스", slug: "eclipse-commerce",
      eyebrow: "WORK · 012", heroImage: "images/carousel-work-02-eclipse.jpg",
      tagline: "한정판 제품을 위한 몰입형 이커머스 경험을 설계했습니다.",
      tags: ["E-commerce", "3D Viewer", "Checkout UX"],
      description: [
        "일식(eclipse)을 모티브로 한 한정판 컬렉션 소개 페이지로, 제품을 360도로 회전시켜볼 수 있는 3D 뷰어를 탑재했습니다.",
        "체크아웃 단계를 최소화해 이탈률을 낮추는 데 집중했습니다."
      ],
      features: ["Three.js 기반 360도 제품 뷰어", "원페이지 체크아웃 플로우", "재고 실시간 표시"] },

    { title: "스텔라 아카이브", slug: "stellar-archive",
      eyebrow: "WORK · 013", heroImage: "images/carousel-work-03-stellar.jpg",
      tagline: "수천 장의 우주 관측 사진을 탐색할 수 있는 아카이브 갤러리입니다.",
      tags: ["Gallery", "Masonry", "Lazy Load"],
      description: [
        "연도, 관측소, 파장대별로 필터링이 가능한 대규모 이미지 아카이브를 구축했습니다.",
        "이미지 지연 로딩과 가상 스크롤을 적용해 수천 장의 고해상도 사진도 매끄럽게 탐색할 수 있습니다."
      ],
      features: ["가상 스크롤 기반 매소너리 레이아웃", "다중 조건 필터링", "이미지 지연 로딩 최적화"] },

    { title: "드리프트 포트폴리오", slug: "drift-portfolio",
      eyebrow: "WORK · 014", heroImage: "images/carousel-work-04-drift.jpg",
      tagline: "우주 부유물처럼 떠다니는 인터랙티브 3D 포트폴리오 사이트입니다.",
      tags: ["Three.js", "WebGL", "Portfolio"],
      description: [
        "마우스 움직임에 따라 3D 오브젝트들이 유영하듯 반응하는 포트폴리오 사이트를 제작했습니다.",
        "성능을 고려해 인스턴싱과 LOD를 적용, 저사양 기기에서도 부드럽게 동작하도록 최적화했습니다."
      ],
      features: ["Three.js 인스턴싱 최적화", "마우스 패럴랙스 인터랙션", "모바일 대응 저사양 모드"] },

    { title: "루미너스 랜딩", slug: "luminous-landing",
      eyebrow: "WORK · 015", heroImage: "images/carousel-work-05-luminous.jpg",
      tagline: "신제품 론칭을 위한 몰입형 스크롤 랜딩 페이지입니다.",
      tags: ["Landing Page", "GSAP", "Storytelling"],
      description: [
        "제품의 핵심 가치를 스크롤 흐름에 따라 순차적으로 드러내는 스토리텔링형 랜딩 페이지입니다.",
        "섹션마다 다른 조명과 색온도를 적용해 제품의 분위기를 시네마틱하게 전달했습니다."
      ],
      features: ["GSAP ScrollTrigger 기반 연출", "섹션별 조명/색온도 변화", "반응형 타이포그래피 시스템"] },

    { title: "코스믹 대시보드", slug: "cosmic-dashboard",
      eyebrow: "WORK · 016", heroImage: "images/carousel-work-06-dashboard.jpg",
      tagline: "복잡한 운영 지표를 한눈에 볼 수 있는 관리자용 SaaS 대시보드입니다.",
      tags: ["SaaS", "Dashboard", "Design System"],
      description: [
        "여러 팀이 함께 사용하는 운영 대시보드를 위해 확장 가능한 디자인 시스템을 먼저 구축했습니다.",
        "위젯 단위로 커스터마이징이 가능해 팀마다 필요한 지표만 골라 배치할 수 있습니다."
      ],
      features: ["드래그 앤 드롭 위젯 커스터마이징", "다크/라이트 테마 지원", "컴포넌트 기반 디자인 시스템"] }
  ],

  /* ---------- Section 6 · 네뷸러 차원 (아코디언 워크 카드) ---------- */
  accordion: [
    { label: "라이브 인터랙션", slug: "live-interaction",
      eyebrow: "WORK · 041", heroImage: "images/work-01-live-interaction.jpg",
      panelBg: "images/work-01.jpg",
      tagline: "사용자의 커서 움직임에 실시간으로 반응하는 인터랙티브 랜딩 페이지입니다.",
      tags: ["Interactive", "WebGL", "Landing Page"],
      description: [
        "사용자의 커서 움직임에 실시간으로 반응하는 인터랙티브 랜딩 페이지입니다.",
        "WebGL 기반 파티클 연출로 몰입감을 더했습니다."
      ],
      features: ["실시간 커서 반응 파티클", "WebGL 기반 렌더링", "저사양 기기 대응 모드"],
      icon: '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8"/>' },

    { label: "아카이브 갤러리", slug: "archive-gallery",
      eyebrow: "WORK · 042", heroImage: "images/work-02-archive-gallery.jpg",
      panelBg: "images/work-02.jpg",
      tagline: "수백 장의 시각 자료를 카테고리별로 탐색할 수 있는 아카이브형 갤러리입니다.",
      tags: ["Gallery", "Filtering", "Motion"],
      description: [
        "수백 장의 시각 자료를 카테고리별로 탐색할 수 있는 아카이브형 갤러리입니다.",
        "필터링과 부드러운 전환 애니메이션에 집중했습니다."
      ],
      features: ["카테고리 기반 필터링", "부드러운 전환 애니메이션", "무한 스크롤 탐색"],
      icon: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>' },

    { label: "브랜드 랜딩", slug: "brand-landing",
      eyebrow: "WORK · 043", heroImage: "images/work-03-brand-landing.jpg",
      panelBg: "images/work-03.jpg",
      tagline: "신규 브랜드 론칭을 위한 원페이지 랜딩입니다.",
      tags: ["Branding", "Landing Page", "Storytelling"],
      description: [
        "신규 브랜드 론칭을 위한 원페이지 랜딩입니다.",
        "미니멀한 타이포와 스크롤 기반 스토리텔링으로 브랜드 톤을 전달합니다."
      ],
      features: ["스크롤 기반 스토리텔링", "미니멀 타이포그래피 시스템", "반응형 히어로 섹션"],
      icon: '<path d="M4 19V5a1 1 0 0 1 1-1h10l5 5v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/><path d="M15 4v5h5"/>' },

    { label: "데이터 비주얼라이제이션", slug: "data-visualization",
      eyebrow: "WORK · 044", heroImage: "images/work-04-data-viz.jpg",
      panelBg: "images/work-04.jpg",
      tagline: "방대한 항성 관측 데이터를 직관적인 차트와 지도로 재구성한 대시보드입니다.",
      tags: ["Dashboard", "Data Viz", "Real-time"],
      description: [
        "방대한 항성 관측 데이터를 직관적인 차트와 지도로 재구성한 대시보드입니다.",
        "실시간 필터와 인터랙티브 차트를 제공합니다."
      ],
      features: ["실시간 데이터 필터", "인터랙티브 차트 컴포넌트", "지도 기반 시각화"],
      icon: '<path d="M4 20V10M12 20V4M20 20v-7"/><path d="M2 20h20"/>' },

    { label: "커머스 익스피리언스", slug: "commerce-experience",
      eyebrow: "WORK · 045", heroImage: "images/work-05-commerce.jpg",
      panelBg: "images/work-05.jpg",
      tagline: "한정판 제품을 위한 커머스 경험 설계입니다.",
      tags: ["E-commerce", "3D", "Checkout UX"],
      description: [
        "한정판 제품을 위한 커머스 경험 설계입니다.",
        "3D 프로덕트 뷰어와 매끄러운 체크아웃 플로우로 전환율을 개선했습니다."
      ],
      features: ["3D 프로덕트 뷰어", "매끄러운 체크아웃 플로우", "재고 실시간 반영"],
      icon: '<circle cx="9" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.5 2.5H5l2.7 12.4a2 2 0 0 0 2 1.6h8.3a2 2 0 0 0 2-1.6L21.5 7H6"/>' }
  ]
};

/* 서브페이지 링크 경로를 만들어주는 헬퍼 (slug가 없으면 null 반환) */
function workLink(slug){
  return slug ? `work.html?work=${encodeURIComponent(slug)}` : null;
}

/* work.html에서 slug로 항목을 찾을 때 쓰는 헬퍼 (모든 카테고리를 합쳐서 검색) */
function findWorkBySlug(slug){
  const all = [
    ...siteWorks.fan,
    ...siteWorks.vcarousel,
    ...siteWorks.carousel,
    ...siteWorks.accordion
  ];
  return all.find(item => item.slug === slug) || null;
}
