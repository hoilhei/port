// 브라우저가 새로고침 시 이전 스크롤 위치를 기억해 엉뚱한 섹션(sector-03 등)에
    // 멈춰 있는 문제를 막기 위해, 항상 맨 위(Section 1)에서 시작하도록 강제합니다.
    if('scrollRestoration' in history){ history.scrollRestoration = 'manual'; }
    window.scrollTo(0, 0);
 
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);
 
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 
    /* =========================================================
       인트로 프리로더 : 타이핑 + 로켓 로딩바
       ------------------------------------------------------
       ★ 문구를 바꾸려면 preloaderText 값만 수정하세요.
       ========================================================= */
    const preloaderText = "내가 가보지 못한 새로운 우주";
    const TYPE_SPEED_MS = 110;      // 한 글자당 타이핑 속도
    const LOAD_DURATION_MS = 2400;  // 로켓 로딩바가 끝까지 차는 데 걸리는 시간
 
    const preloaderEl = document.getElementById('preloader');
    const typeTargetEl = document.getElementById('typeTarget');
    const loaderFillEl = document.getElementById('loaderFill');
    const loaderStarEl = document.getElementById('loaderStar');
    const preloaderBtnEl = document.getElementById('preloaderBtn');
    const BUTTON_REVEAL_PERCENT = 90; // 이 값(%)에 도달하면 이동하기 버튼 노출
 
    function typePreloaderText(){
      let charIndex = 0;
      function typeNext(){
        if(charIndex < preloaderText.length){
          typeTargetEl.textContent += preloaderText[charIndex];
          charIndex++;
          setTimeout(typeNext, TYPE_SPEED_MS);
        } else {
          runLoaderProgress();
        }
      }
      typeNext();
    }
 
    function runLoaderProgress(){
      const startTime = performance.now();
      let buttonRevealed = false;
      function step(now){
        const elapsed = now - startTime;
        const progress = Math.min(100, (elapsed / LOAD_DURATION_MS) * 100);
        loaderFillEl.style.width = progress + '%';
        loaderStarEl.style.left = progress + '%';
        if(progress >= BUTTON_REVEAL_PERCENT && !buttonRevealed){
          buttonRevealed = true;
          preloaderBtnEl.classList.add('is-visible');
        }
        if(progress < 100){
          requestAnimationFrame(step);
        }
      }
      requestAnimationFrame(step);
    }
 
    function dismissPreloader(){
      window.scrollTo(0, 0); // 인트로 배경 미디어(Section 1)가 확실히 보이도록 최상단으로 이동
      preloaderEl.classList.add('is-hidden');
      document.body.classList.remove('preloading');
      setTimeout(() => {
        preloaderEl.style.display = 'none';
        window.scrollTo(0, 0);
        ScrollTrigger.refresh();
      }, 950);
      startIntroVideo(); // 이동하기 클릭과 동시에 인트로 영상 재생 시작
    }
 
    if(preloaderEl){
      if(reduceMotion){
        typeTargetEl.textContent = preloaderText;
        loaderFillEl.style.width = '100%';
        loaderStarEl.style.left = '100%';
        preloaderBtnEl.classList.add('is-visible');
      } else {
        setTimeout(typePreloaderText, 500); // 검은 화면이 잠깐 자리잡은 뒤 타이핑 시작
      }
      preloaderBtnEl.addEventListener('click', dismissPreloader);
    }
 
    /* =========================================================
       Section 1 인트로 영상 : 재생이 끝나면 어두워지며 Section 2로 자동 스크롤
       ------------------------------------------------------
       ★ 실제 영상을 쓰려면 introBgVideo의 <source src="..."> 경로를
         assets 폴더에 넣은 실제 파일명으로 바꿔주세요.
       ========================================================= */
    const introVideoEl = document.getElementById('introBgVideo');
    const introImageEl = document.getElementById('introBgImage');
    const introDarkenEl = document.getElementById('introDarken');
    const INTRO_FALLBACK_MS = 6000; // 영상을 재생할 수 없을 때 대신 기다리는 시간
    let introEndingTriggered = false;
    let introFallbackTimer = null;
 
    function playIntroEnding(){
      if(introEndingTriggered) return;
      introEndingTriggered = true;
      if(introFallbackTimer) clearTimeout(introFallbackTimer);
 
      // 자연스럽게 어두워짐
      gsap.to([introVideoEl, introImageEl], { opacity: 0, duration: 1.4, ease: 'power2.inOut' });
      gsap.to(introDarkenEl, { opacity: 1, duration: 1.4, ease: 'power2.inOut' });
 
      // 어두워지는 동안 자연스럽게 SECTOR-03으로 스크롤 이동
      gsap.to(window, {
        duration: 1.6,
        delay: 0.5,
        scrollTo: { y: '#section-2', offsetY: 0 },
        ease: 'power2.inOut'
      });
    }
 
    function startIntroVideo(){
      if(!introVideoEl) return;
      if(reduceMotion){
        // 모션을 최소화하는 사용자에게는 영상 연출을 강제하지 않음
        return;
      }
      const playPromise = introVideoEl.play();
      if(playPromise && typeof playPromise.then === 'function'){
        playPromise.then(() => {
          // 재생 성공: 영상이 GIF 위로 자연스럽게 드러남
          gsap.to(introVideoEl, { opacity: 1, duration: 0.8, ease: 'power1.out' });
        }).catch(() => {
          // 자동재생이 막힌 경우 등: GIF만 보여주고, 일정 시간 뒤 동일한 연출로 넘어감
          introFallbackTimer = setTimeout(playIntroEnding, INTRO_FALLBACK_MS);
        });
      }
      introVideoEl.addEventListener('ended', playIntroEnding);
      introVideoEl.addEventListener('error', () => {
        introFallbackTimer = setTimeout(playIntroEnding, INTRO_FALLBACK_MS);
      });
    }
 
    /* =========================================================
       프로필 데이터 (Section 2)
       ------------------------------------------------------
       ★ 이 객체의 값만 바꾸면 화면이 자동으로 업데이트됩니다.
       ★ 아이콘은 아래 socialIcons 맵의 key(mail/github/linkedin/web) 중 하나를 쓰면 됩니다.
       ========================================================= */
    const profileData = {
      eyebrow: "EXPLORER LOG",
      name: "YOUR NAME",
      role: "FRONTEND DEVELOPER · CREATIVE CODER",
 
      // 왼쪽 메뉴 리스트 (원하는 만큼 추가/삭제 가능)
      menu: [
        { icon: "◎", title: "ABOUT ME",   sub: "저를 소개합니다",   active: true  },
        { icon: "✎", title: "SKILLS",     sub: "사용하는 기술"                    },
        { icon: "🗂", title: "EXPERIENCE", sub: "지나온 경력"                     },
        { icon: "✉", title: "CONTACT",    sub: "연락하기"                        }
      ],
 
      // 왼쪽 하단 소개 카드
      quote: {
        image: "images/profile-quote.jpg",
        title: "EXPLORE. CREATE. BUILD.",
        desc: "사용자 경험과 인터랙션의 경계를 탐험하는 프론트엔드 개발자입니다."
      },
 
      // 오른쪽 상단 스탯 카드
      stat: {
        avatarInitial: "YN",
        playerLabel: "YOUR NAME",
        roleLabel: "Frontend Explorer",
        level: 5,
        xpCurrent: 3200,
        xpMax: 5000
      },
 
      // 오른쪽 스킬 카드 (0~100 사이 값)
      skills: [
        { name: "React / TypeScript",     value: 90 },
        { name: "UI 애니메이션 (GSAP)",    value: 85 },
        { name: "3D / WebGL",             value: 60 },
        { name: "디자인 시스템",           value: 75 }
      ],
      achievement: "최근 성취 · OOO 프로젝트 런칭 (+500 XP)",
 
      // 소셜 링크 (icon: mail / github / linkedin / web 중 선택)
      social: [
        { icon: "mail",     href: "mailto:you@example.com" },
        { icon: "github",   href: "https://github.com/yourid" },
        { icon: "linkedin", href: "https://linkedin.com/in/yourid" },
        { icon: "web",      href: "https://yourwebsite.com" }
      ]
    };
 
    const socialIcons = {
      mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>',
      github: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1.1-.3-3.5 1.3a12.3 12.3 0 0 0-6.2 0C6.5 3.7 5.4 4 5.4 4a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 10.4c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2V22"/></svg>',
      linkedin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 10v7M7 7v.01M12 17v-4a2 2 0 0 1 4 0v4M12 13v4"/></svg>',
      web: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>'
    };
 
    function renderProfile(data){
      document.getElementById('profileEyebrow').textContent = data.eyebrow;
      document.getElementById('profileName').textContent = data.name;
      document.getElementById('profileRole').textContent = data.role;
 
      // 메뉴
      const menuEl = document.getElementById('profileMenu');
      menuEl.innerHTML = data.menu.map(item => `
        <li class="menu-item${item.active ? ' active' : ''}">
          <span class="menu-icon">${item.icon}</span>
          <span class="menu-text">
            <span class="menu-title">${item.title}</span>
            <span class="menu-sub">${item.sub}</span>
          </span>
        </li>
      `).join('');
 
      // 소개 카드
      const quoteEl = document.getElementById('profileQuote');
      quoteEl.innerHTML = `
        <div class="quote-bg" style="background-image:url('${data.quote.image}')"></div>
        <div class="quote-body">
          <p class="quote-title">${data.quote.title}</p>
          <p class="quote-desc">${data.quote.desc}</p>
        </div>
      `;
 
      // 스탯 카드
      const statEl = document.getElementById('profileStat');
      const xpPct = Math.min(100, Math.round((data.stat.xpCurrent / data.stat.xpMax) * 100));
      statEl.innerHTML = `
        <div class="stat-header">
          <div class="avatar-badge">${data.stat.avatarInitial}</div>
          <div class="stat-name-block">
            <span class="stat-name">${data.stat.playerLabel}</span>
            <span class="stat-role">${data.stat.roleLabel}</span>
            <span class="stat-level">LEVEL ${String(data.stat.level).padStart(2,'0')}</span>
          </div>
        </div>
        <div class="xp-bar"><div class="xp-fill" style="width:${xpPct}%"></div></div>
        <span class="xp-label">${data.stat.xpCurrent.toLocaleString()} / ${data.stat.xpMax.toLocaleString()} XP</span>
      `;
 
      // 스킬 카드
      const skillsEl = document.getElementById('profileSkills');
      skillsEl.innerHTML = `
        <span class="card-heading">CURRENT FOCUS</span>
        <ul class="skill-list">
          ${data.skills.map(s => `
            <li class="skill-row">
              <div class="skill-top"><span>${s.name}</span><span>${s.value}%</span></div>
              <div class="skill-bar"><div class="skill-fill" style="width:${s.value}%"></div></div>
            </li>
          `).join('')}
        </ul>
        <div class="achievement-line">★ ${data.achievement}</div>
      `;
 
      // 소셜 링크
      const socialEl = document.getElementById('profileSocial');
      socialEl.innerHTML = data.social.map(s => `
        <a class="social-btn" href="${s.href}" target="_blank" rel="noopener">${socialIcons[s.icon] || ''}</a>
      `).join('');
    }
 
    renderProfile(profileData);
 
    /* ---------- 별 생성 (box-shadow 트릭) ---------- */
    function generateStars(el, count, color){
      const w = window.innerWidth * 1.3;
      const h = window.innerHeight * 1.3;
      let shadows = [];
      for(let i=0;i<count;i++){
        const x = Math.round(Math.random()*w);
        const y = Math.round(Math.random()*h);
        const size = Math.random() > 0.85 ? '2px' : '1px';
        shadows.push(`${x}px ${y}px 0 ${size==='2px'?'1px':'0'} ${color}`);
      }
      el.style.boxShadow = shadows.join(',');
      el.style.width = size2(1);
      el.style.height = size2(1);
    }
    function size2(v){ return v+'px'; }
 
    generateStars(document.getElementById('stars-1'), 140, 'rgba(255,247,224,0.75)');
    generateStars(document.getElementById('stars-2'), 140, 'rgba(210,255,248,0.7)');
    generateStars(document.getElementById('stars-3'), 140, 'rgba(200,225,255,0.75)');
    generateStars(document.getElementById('stars-4'), 140, 'rgba(255,224,200,0.7)');
    generateStars(document.getElementById('stars-5'), 140, 'rgba(232,210,255,0.7)');
 
    /* ---------- 배경 전환 (크로스페이드) ---------- */
    const sectionCount = 5;
    const dots = gsap.utils.toArray('.dot');
 
    function setActive(index){
      gsap.utils.toArray('.bg-layer').forEach((layer, i) => {
        gsap.to(layer, { opacity: (i === index-1) ? 1 : 0, duration: 1.3, ease: 'power2.inOut' });
      });
      dots.forEach((d, i) => d.classList.toggle('active', i === index-1));
    }
 
    for(let i=1;i<=sectionCount;i++){
      const section = document.getElementById(`section-${i}`);
      const bgInner = document.querySelector(`#bg-${i} .bg-inner`);
 
      // 배경 줌인 (scrub 기반 스케일업)
      if(!reduceMotion){
        gsap.fromTo(bgInner,
          { scale: 1 },
          {
            scale: 1.18,
            ease: 'none',
            scrollTrigger:{
              trigger: section,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true
            }
          }
        );
      }
 
      // 섹션 진입 시 배경 크로스페이드 전환
      ScrollTrigger.create({
        trigger: section,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => setActive(i),
        onEnterBack: () => setActive(i)
      });
 
      // 카드 등장 애니메이션 (글래스 카드)
      const card = section.querySelector('.glass-card');
      if(card){
        gsap.fromTo(card,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: card,
              start: 'top 82%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
 
      // 프로필 그리드 등장 애니메이션 (Section 2)
      const profileGrid = section.querySelector('.profile-grid');
      if(profileGrid){
        gsap.fromTo(profileGrid,
          { opacity: 0, y: 40 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: profileGrid,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
 
      // 아코디언 등장 애니메이션 (Section 5)
      const accordion = section.querySelector('.accordion');
      if(accordion){
        gsap.fromTo(accordion,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: accordion,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
 
      // 수직 순환 캐러셀 등장 애니메이션 (Section 3)
      const vStage = section.querySelector('.vcarousel-stage');
      if(vStage){
        gsap.fromTo(vStage,
          { opacity: 0, y: 50 },
          {
            opacity: 1, y: 0, duration: 1,
            ease: 'power3.out',
            scrollTrigger:{
              trigger: vStage,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    }
 
    /* ---------- 우측 내비게이션 클릭 ---------- */
    dots.forEach(dot => {
      dot.addEventListener('click', () => {
        gsap.to(window, {
          duration: 1.1,
          scrollTo: { y: `#${dot.dataset.target}`, offsetY: 0 },
          ease: 'power2.inOut'
        });
      });
    });
 
    /* ---------- 워크 아코디언 (Section 3) : 터치 기기 탭-확장 처리 ---------- */
    const panels = document.querySelectorAll('.panel');
    const hasHover = window.matchMedia('(hover: hover)').matches;
 
    panels.forEach(panel => {
      panel.addEventListener('click', (e) => {
        if(!hasHover && !panel.classList.contains('active')){
          // 터치 기기: 첫 탭은 카드 확장만, 두 번째 탭에서 실제 이동
          e.preventDefault();
          panels.forEach(p => p.classList.remove('active'));
          panel.classList.add('active');
        }
        // hasHover(데스크톱) 환경에서는 기본 링크 동작으로 바로 이동
      });
    });
 
    /* =========================================================
       회전 캐러셀 워크 데이터 (Section 3)
       ------------------------------------------------------
       ★ 이 배열의 값만 바꾸면 카드 내용과 팝업 내용이 자동으로 바뀝니다.
       ★ heroImage 경로에 실제 썸네일 이미지를 넣으면 카드/팝업에 반영됩니다.
       ========================================================= */
    const carouselProjects = [
      {
        eyebrow: "WORK · 011",
        title: "오로라 오케스트레이션",
        tagline: "실시간 위성 데이터를 오로라처럼 흐르는 대시보드로 시각화한 프로젝트입니다.",
        tags: ["Data Viz", "D3.js", "WebSocket"],
        heroImage: "images/carousel-work-01.jpg",
        description: [
          "우주 관측소에서 수집되는 실시간 데이터를 초 단위로 갱신되는 대시보드로 재구성했습니다.",
          "복잡한 수치를 오로라의 흐름처럼 자연스러운 곡선과 색상 변화로 표현해 직관적으로 읽히도록 설계했습니다."
        ],
        features: ["실시간 WebSocket 데이터 스트리밍", "커스텀 D3.js 시각화 컴포넌트", "다크모드 전용 컬러 시스템"],
        link: "https://example.com/work/aurora-orchestration"
      },
      {
        eyebrow: "WORK · 012",
        title: "이클립스 커머스",
        tagline: "한정판 제품을 위한 몰입형 이커머스 경험을 설계했습니다.",
        tags: ["E-commerce", "3D Viewer", "Checkout UX"],
        heroImage: "images/carousel-work-02.jpg",
        description: [
          "일식(eclipse)을 모티브로 한 한정판 컬렉션 소개 페이지로, 제품을 360도로 회전시켜볼 수 있는 3D 뷰어를 탑재했습니다.",
          "체크아웃 단계를 최소화해 이탈률을 낮추는 데 집중했습니다."
        ],
        features: ["Three.js 기반 360도 제품 뷰어", "원페이지 체크아웃 플로우", "재고 실시간 표시"],
        link: "https://example.com/work/eclipse-commerce"
      },
      {
        eyebrow: "WORK · 013",
        title: "스텔라 아카이브",
        tagline: "수천 장의 우주 관측 사진을 탐색할 수 있는 아카이브 갤러리입니다.",
        tags: ["Gallery", "Masonry", "Lazy Load"],
        heroImage: "images/carousel-work-03.jpg",
        description: [
          "연도, 관측소, 파장대별로 필터링이 가능한 대규모 이미지 아카이브를 구축했습니다.",
          "이미지 지연 로딩과 가상 스크롤을 적용해 수천 장의 고해상도 사진도 매끄럽게 탐색할 수 있습니다."
        ],
        features: ["가상 스크롤 기반 매소너리 레이아웃", "다중 조건 필터링", "이미지 지연 로딩 최적화"],
        link: "https://example.com/work/stellar-archive"
      },
      {
        eyebrow: "WORK · 014",
        title: "드리프트 포트폴리오",
        tagline: "우주 부유물처럼 떠다니는 인터랙티브 3D 포트폴리오 사이트입니다.",
        tags: ["Three.js", "WebGL", "Portfolio"],
        heroImage: "images/carousel-work-04.jpg",
        description: [
          "마우스 움직임에 따라 3D 오브젝트들이 유영하듯 반응하는 포트폴리오 사이트를 제작했습니다.",
          "성능을 고려해 인스턴싱과 LOD를 적용, 저사양 기기에서도 부드럽게 동작하도록 최적화했습니다."
        ],
        features: ["Three.js 인스턴싱 최적화", "마우스 패럴랙스 인터랙션", "모바일 대응 저사양 모드"],
        link: "https://example.com/work/drift-portfolio"
      },
      {
        eyebrow: "WORK · 015",
        title: "루미너스 랜딩",
        tagline: "신제품 론칭을 위한 몰입형 스크롤 랜딩 페이지입니다.",
        tags: ["Landing Page", "GSAP", "Storytelling"],
        heroImage: "images/carousel-work-05.jpg",
        description: [
          "제품의 핵심 가치를 스크롤 흐름에 따라 순차적으로 드러내는 스토리텔링형 랜딩 페이지입니다.",
          "섹션마다 다른 조명과 색온도를 적용해 제품의 분위기를 시네마틱하게 전달했습니다."
        ],
        features: ["GSAP ScrollTrigger 기반 연출", "섹션별 조명/색온도 변화", "반응형 타이포그래피 시스템"],
        link: "https://example.com/work/luminous-landing"
      },
      {
        eyebrow: "WORK · 016",
        title: "코스믹 대시보드",
        tagline: "복잡한 운영 지표를 한눈에 볼 수 있는 관리자용 SaaS 대시보드입니다.",
        tags: ["SaaS", "Dashboard", "Design System"],
        heroImage: "images/carousel-work-06.jpg",
        description: [
          "여러 팀이 함께 사용하는 운영 대시보드를 위해 확장 가능한 디자인 시스템을 먼저 구축했습니다.",
          "위젯 단위로 커스터마이징이 가능해 팀마다 필요한 지표만 골라 배치할 수 있습니다."
        ],
        features: ["드래그 앤 드롭 위젯 커스터마이징", "다크/라이트 테마 지원", "컴포넌트 기반 디자인 시스템"],
        link: "https://example.com/work/cosmic-dashboard"
      }
    ];
 
    /* ---------- 캐러셀 카드 생성 ---------- */
    const carouselRing = document.getElementById('carouselRing');
    const carouselStage = document.getElementById('carouselStage');
    const angleStep = 360 / carouselProjects.length;
    const carouselRadius = 320;
 
    carouselProjects.forEach((proj, i) => {
      const angle = i * angleStep;
      const card = document.createElement('div');
      card.className = 'carousel-card';
      card.style.transform = `rotateY(${angle}deg) translateZ(${carouselRadius}px)`;
      card.innerHTML = `
        <div class="card-face card-front">
          <div class="card-bg" style="background-image:url('${proj.heroImage}')"></div>
          <div class="card-shade"></div>
          <span class="card-label">${proj.eyebrow}<br>${proj.title}</span>
          <span class="card-cta">작업 보기 →</span>
        </div>
        <div class="card-face card-back">
          <span class="back-index">${proj.eyebrow}</span>
          <span class="back-ring"></span>
          <span class="back-caption">회전 중입니다<br>정면으로 오면 자세히 볼 수 있어요</span>
        </div>
      `;
      card.addEventListener('click', (e) => {
        if(carouselDragDistance > 6) return; // 드래그 후 발생하는 클릭은 무시
        if(card.classList.contains('is-front') && e.target.closest('.card-cta')){
          openWorkModal(proj);
        }
      });
      carouselRing.appendChild(card);
    });
 
    /* ---------- 캐러셀 회전 (아주 천천히 왼쪽으로) ---------- */
    let carouselRotation = 0;
    let carouselPaused = false;
    let carouselLastTime = null;
    const CAROUSEL_TURN_MS = 90000; // 한 바퀴 도는 데 걸리는 시간(ms) - 클수록 더 느리게 회전
    const CAROUSEL_SPEED = 360 / CAROUSEL_TURN_MS;
 
    function normalizeAngle(a){
      a = a % 360;
      if(a > 180) a -= 360;
      if(a < -180) a += 360;
      return a;
    }
 
    function updateFrontCard(){
      let frontCard = null;
      let minAbs = Infinity;
      Array.from(carouselRing.children).forEach((card, i) => {
        const angle = normalizeAngle(i * angleStep + carouselRotation);
        const absAngle = Math.abs(angle);
        if(absAngle < minAbs){ minAbs = absAngle; frontCard = card; }
      });
      Array.from(carouselRing.children).forEach(card => {
        card.classList.toggle('is-front', card === frontCard);
      });
    }
 
    function animateCarousel(time){
      if(carouselLastTime === null) carouselLastTime = time;
      const delta = time - carouselLastTime;
      carouselLastTime = time;
      if(!carouselPaused && !reduceMotion){
        carouselRotation -= delta * CAROUSEL_SPEED; // 음수 방향 = 왼쪽으로 회전
        carouselRing.style.transform = `rotateY(${carouselRotation}deg)`;
      }
      updateFrontCard();
      requestAnimationFrame(animateCarousel);
    }
    requestAnimationFrame(animateCarousel);
 
    if(carouselStage){
      carouselStage.addEventListener('mouseenter', () => { carouselPaused = true; });
      carouselStage.addEventListener('mouseleave', () => { if(!carouselDragging) carouselPaused = false; });
    }
 
    /* ---------- 드래그로 캐러셀 직접 회전 ---------- */
    let carouselDragging = false;
    let carouselDragStartX = 0;
    let carouselDragStartRotation = 0;
    let carouselDragDistance = 0;
    const DRAG_SENSITIVITY = 0.35; // 1px 드래그당 회전하는 각도
 
    if(carouselStage){
      carouselStage.addEventListener('pointerdown', (e) => {
        carouselDragging = true;
        carouselDragDistance = 0;
        carouselDragStartX = e.clientX;
        carouselDragStartRotation = carouselRotation;
        carouselPaused = true;
        carouselStage.classList.add('is-dragging');
        carouselStage.setPointerCapture(e.pointerId);
      });
 
      carouselStage.addEventListener('pointermove', (e) => {
        if(!carouselDragging) return;
        const deltaX = e.clientX - carouselDragStartX;
        carouselDragDistance = Math.abs(deltaX);
        carouselRotation = carouselDragStartRotation + deltaX * DRAG_SENSITIVITY;
        carouselRing.style.transform = `rotateY(${carouselRotation}deg)`;
        updateFrontCard();
      });
 
      const endCarouselDrag = () => {
        if(!carouselDragging) return;
        carouselDragging = false;
        carouselStage.classList.remove('is-dragging');
        if(!carouselStage.matches(':hover')) carouselPaused = false;
      };
      carouselStage.addEventListener('pointerup', endCarouselDrag);
      carouselStage.addEventListener('pointercancel', endCarouselDrag);
      carouselStage.addEventListener('pointerleave', endCarouselDrag);
    }
 
    /* =========================================================
       수직 순환 카드 캐러셀 (Section 3 · 오르빗 차원)
       ------------------------------------------------------
       ★ 카드 내용/링크는 이 배열만 바꾸면 됩니다.
       ========================================================= */
    const vcarouselProjects = [
      { number: "01", title: "Signal Drift",  sub: "Web App",       gradient: "linear-gradient(135deg, #12324f, #6fe7dc)", link: "https://example.com/work/signal-drift" },
      { number: "02", title: "Inner Cycle",   sub: "Desktop",       gradient: "linear-gradient(135deg, #3a1f14, #ff9b5c)", link: "https://example.com/work/inner-cycle" },
      { number: "03", title: "Halo Market",   sub: "E-commerce",    gradient: "linear-gradient(135deg, #241238, #c97bff)", link: "https://example.com/work/halo-market" },
      { number: "04", title: "Nova Studio",   sub: "Branding",      gradient: "linear-gradient(135deg, #3a2a10, #f3c77a)", link: "https://example.com/work/nova-studio" },
      { number: "05", title: "Quiet Orbit",   sub: "Landing Page",  gradient: "linear-gradient(135deg, #16233a, #7fc4ff)", link: "https://example.com/work/quiet-orbit" }
    ];
 
    const vcarouselRing = document.getElementById('vcarouselRing');
    const vcarouselStage = document.getElementById('vcarouselStage');
    const vAngleStep = 360 / vcarouselProjects.length;
    const vRadius = 240;
 
    vcarouselProjects.forEach((proj, i) => {
      const angle = i * vAngleStep;
      const card = document.createElement('div');
      card.className = 'vcarousel-card';
      card.style.transform = `rotateX(${angle}deg) translateZ(${vRadius}px)`;
      card.innerHTML = `
        <div class="vcard-thumb" style="background:${proj.gradient}"></div>
        <div class="vcard-shade"></div>
        <span class="vcard-number">${proj.number}</span>
        <div class="vcard-text">
          <p class="vcard-title">${proj.title}</p>
          <p class="vcard-sub">${proj.sub}</p>
        </div>
        <a class="vcard-cta" href="${proj.link}" target="_blank" rel="noopener">이동하기 →</a>
      `;
      const cta = card.querySelector('.vcard-cta');
      cta.addEventListener('click', (e) => {
        if(vDragDistance > 6) e.preventDefault(); // 드래그 후 발생하는 클릭은 무시
      });
      // 카드 "모양" 위에 마우스가 있을 때만 회전을 멈추고, 주변(빈 공간)에서는 계속 회전
      card.addEventListener('mouseenter', () => { vPaused = true; });
      card.addEventListener('mouseleave', () => { if(!vDragging) vPaused = false; });
      vcarouselRing.appendChild(card);
    });
 
    /* ---------- 수직 회전 (위에서 아래로 흐르며 원을 그리며 순환) ---------- */
    let vRotation = 0;
    let vPaused = false;
    let vLastTime = null;
    const VCAROUSEL_TURN_MS = 39000; // 한 바퀴 도는 데 걸리는 시간(ms) - 기존 대비 50% 더 느리게
    const V_SPEED = 360 / VCAROUSEL_TURN_MS;
 
    function updateFrontCardV(){
      let frontCard = null;
      let minAbs = Infinity;
      Array.from(vcarouselRing.children).forEach((card, i) => {
        const angle = normalizeAngle(i * vAngleStep + vRotation);
        const absAngle = Math.abs(angle);
        if(absAngle < minAbs){ minAbs = absAngle; frontCard = card; }
      });
      Array.from(vcarouselRing.children).forEach(card => {
        card.classList.toggle('is-front', card === frontCard);
      });
    }
 
    function animateVCarousel(time){
      if(vLastTime === null) vLastTime = time;
      const delta = time - vLastTime;
      vLastTime = time;
      if(!vPaused && !reduceMotion){
        vRotation += delta * V_SPEED; // 양수 방향 = 위→아래로 흐르는 방향
        vcarouselRing.style.transform = `rotateX(${vRotation}deg)`;
      }
      updateFrontCardV();
      requestAnimationFrame(animateVCarousel);
    }
    requestAnimationFrame(animateVCarousel);
 
    if(vcarouselStage){
      vcarouselStage.addEventListener('mouseenter', () => { vPaused = true; });
      vcarouselStage.addEventListener('mouseleave', () => { if(!vDragging) vPaused = false; });
    }
 
    /* ---------- 드래그로 카드 위/아래 이동 ---------- */
    let vDragging = false;
    let vDragStartY = 0;
    let vDragStartRotation = 0;
    let vDragDistance = 0;
    const V_DRAG_SENSITIVITY = 0.35; // 1px 드래그당 회전하는 각도
 
    if(vcarouselStage){
      vcarouselStage.addEventListener('pointerdown', (e) => {
        vDragging = true;
        vDragDistance = 0;
        vDragStartY = e.clientY;
        vDragStartRotation = vRotation;
        vPaused = true;
        vcarouselStage.classList.add('is-dragging');
        vcarouselStage.setPointerCapture(e.pointerId);
      });
 
      vcarouselStage.addEventListener('pointermove', (e) => {
        if(!vDragging) return;
        const deltaY = e.clientY - vDragStartY;
        vDragDistance = Math.abs(deltaY);
        vRotation = vDragStartRotation + deltaY * V_DRAG_SENSITIVITY;
        vcarouselRing.style.transform = `rotateX(${vRotation}deg)`;
        updateFrontCardV();
      });
 
      const endVDrag = () => {
        if(!vDragging) return;
        vDragging = false;
        vcarouselStage.classList.remove('is-dragging');
        if(!vcarouselStage.matches(':hover')) vPaused = false;
      };
      vcarouselStage.addEventListener('pointerup', endVDrag);
      vcarouselStage.addEventListener('pointercancel', endVDrag);
      vcarouselStage.addEventListener('pointerleave', endVDrag);
    }
 
    /* ---------- 작업물 상세 팝업 ---------- */
    const workModalOverlay = document.getElementById('workModalOverlay');
    const workModalClose = document.getElementById('workModalClose');
    const modalHero = document.getElementById('modalHero');
    const modalBody = document.getElementById('modalBody');
 
    function openWorkModal(proj){
      modalHero.style.backgroundImage = `url('${proj.heroImage}')`;
      modalBody.innerHTML = `
        <span class="modal-eyebrow">${proj.eyebrow}</span>
        <h2 class="modal-title">${proj.title}</h2>
        <p class="modal-tagline">${proj.tagline}</p>
        <div class="modal-tags">${proj.tags.map(t => `<span>${t}</span>`).join('')}</div>
        <p class="modal-section-title">Overview</p>
        ${proj.description.map(p => `<p>${p}</p>`).join('')}
        <p class="modal-section-title">Key Features</p>
        <ul>${proj.features.map(f => `<li>${f}</li>`).join('')}</ul>
        <a class="modal-link" href="${proj.link}" target="_blank" rel="noopener">사이트 방문하기 →</a>
      `;
      workModalOverlay.classList.add('open');
      workModalOverlay.querySelector('.modal-box').scrollTop = 0;
      document.body.style.overflow = 'hidden';
      carouselPaused = true;
    }
 
    function closeWorkModal(){
      workModalOverlay.classList.remove('open');
      document.body.style.overflow = '';
    }
 
    if(workModalClose) workModalClose.addEventListener('click', closeWorkModal);
    if(workModalOverlay){
      workModalOverlay.addEventListener('click', (e) => {
        if(e.target === workModalOverlay) closeWorkModal();
      });
    }
    document.addEventListener('keydown', (e) => {
      if(e.key === 'Escape') closeWorkModal();
    });
 
    window.addEventListener('resize', () => {
      generateStars(document.getElementById('stars-1'), 140, 'rgba(255,247,224,0.75)');
      generateStars(document.getElementById('stars-2'), 140, 'rgba(210,255,248,0.7)');
      generateStars(document.getElementById('stars-3'), 140, 'rgba(200,225,255,0.75)');
      generateStars(document.getElementById('stars-4'), 140, 'rgba(255,224,200,0.7)');
      generateStars(document.getElementById('stars-5'), 140, 'rgba(232,210,255,0.7)');
      ScrollTrigger.refresh();
    });